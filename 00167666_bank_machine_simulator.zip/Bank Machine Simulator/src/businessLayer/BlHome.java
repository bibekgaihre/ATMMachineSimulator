package businessLayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import databaseLayer.database_connection;
import entityLayer.ElHome;


public class BlHome {
		database_connection dc;
		Connection con;
		PreparedStatement ps;
		int rowcount;
		static ResultSet rs;
		
		public BlHome(){
			dc=new database_connection();
			con=dc.connect();
			
		}
		
		//creating method for "basic" account
		public int insertData(ElHome el){
		
			
			String ins="INSERT INTO `tbl_user` (`userid`, `name`, `address`, `contactno`, `email`, `pin`) VALUES (?,?,?,?,?,?)";
			
			try{
				ps=con.prepareStatement(ins);
				
				ps.setInt(1, el.getUserid());
				ps.setString(2, el.getUsername());
				ps.setString(3, el.getAddress());
				ps.setString(4, el.getContactno());
				ps.setString(5, el.getEmail());
				ps.setString(6, el.getPin());
			
				  rowcount = ps.executeUpdate();
			}
			catch(SQLException ex){
				System.out.println(ex.getMessage());
			}
			return rowcount;
			
		}
		

		
		public ResultSet checkData(ElHome el){
			String check="SELECT * FROM `tbl_user` WHERE `userid`='"+el.getUserid()+"' AND `pin`='"+el.getPin()+"'";
			try{
				ps=con.prepareStatement(check);
				rs=ps.executeQuery();
					
					}
			catch(SQLException ex){
				System.out.println(ex.getMessage());
			}
			return rs;
		}
		
		
}
		

