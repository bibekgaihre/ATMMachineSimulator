package businessLayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import databaseLayer.database_connection;
import entityLayer.ElHome;
import entityLayer.ElOverdraft;

public class BlOverdraft {
	database_connection dc;
	Connection con;
	PreparedStatement ps,ps1;
	int rowcount;
	public BlOverdraft() {
		dc=new database_connection();
		con=dc.connect();
	}
	public int insertOverdraft(ElOverdraft eo){
		
		
		String over="UPDATE `tbl_account` SET `overdraft` = '"+eo.getLoan()+"' WHERE `tbl_account`.`accno` = '"+eo.getAccountno()+"'";
		String transactionoverdraft="INSERT INTO `tbl_transaction` (`transactiontype`, `accno`, `transaction_amount`) VALUES (?,?,?)";
		
		try{
			ps=con.prepareStatement(over);
			ps1=con.prepareStatement(transactionoverdraft);
			ps1.setString(1, "Overdraft");
			ps1.setInt(2, eo.getAccountno());
			ps1.setDouble(3, eo.getLoan());
		
			  rowcount = ps.executeUpdate();
			  rowcount=ps1.executeUpdate();
		}
		catch(SQLException ex){
			System.out.println(ex.getMessage());
		}
		return rowcount;
		
	}
	

}
