package businessLayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import databaseLayer.database_connection;
import entityLayer.ElAccounts;
import entityLayer.ElCloseAccount;
import entityLayer.ElCreateAccount;

public class BlCloseAccount {
	database_connection dc;
	Connection con;
	PreparedStatement ps;
	int rowcount;
	static ResultSet rs;
	public BlCloseAccount() {
		// TODO Auto-generated constructor stub
		dc=new database_connection();
		con=dc.connect();
	}
	public ResultSet showAccount(ElCloseAccount ec){
		String check="SELECT accno,balance,date FROM tbl_account WHERE userid='"+ec.getUserid()+"'" ;
		try{
			ps=con.prepareStatement(check);
			
			rs=ps.executeQuery();
				
				}
		catch(SQLException ex){
			System.out.println(ex.getMessage());
		}
		return rs;
	}
	public int deleteAccount(ElCloseAccount ec){
		String delete="DELETE FROM `tbl_account` WHERE `tbl_account`.`accno` = '"+ec.getAccno()+"'";
		try{
			ps=con.prepareStatement(delete);
			rowcount=ps.executeUpdate();
		}
		catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return rowcount;
	}
}
