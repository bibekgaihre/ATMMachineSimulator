package businessLayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import databaseLayer.database_connection;
import entityLayer.ElAccountType;
import entityLayer.ElCreateAccount;

public class BlAccountType {
	database_connection dc;
	Connection con;
	PreparedStatement ps;
	int rowcount;
	public BlAccountType() {
		dc=new database_connection();
		con=dc.connect();
	}
	public int changeaccount(ElAccountType at){
		String change="UPDATE `tbl_account` SET `acctypeID` = 1 WHERE `tbl_account`.`accno` = '"+at.getAccountno()+"'";
		try{
			ps=con.prepareStatement(change);
			
			
			
		rowcount=ps.executeUpdate();
			
		}
		catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return rowcount;
	}
	
	public int changeaccount1(ElAccountType at){
		String change="UPDATE `tbl_account` SET `acctypeID` = 2 WHERE `tbl_account`.`accno` = '"+at.getAccountno()+"'";
		try{
			ps=con.prepareStatement(change);
			
			
			
		rowcount=ps.executeUpdate();
			
		}
		catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return rowcount;
	}
	public int changeaccount2(ElAccountType at){
		String change="UPDATE `tbl_account` SET `acctypeID` = 2 WHERE `tbl_account`.`accno` = '"+at.getAccountno()+"'";
		try{
			ps=con.prepareStatement(change);
			
			
			
		rowcount=ps.executeUpdate();
			
		}
		catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return rowcount;
	}
	
}
