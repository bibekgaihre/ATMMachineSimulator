package businessLayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import databaseLayer.database_connection;
import entityLayer.ElCreateAccount;
import entityLayer.ElHome;

public class BlCreateAccount {
	database_connection dc;
	Connection con;
	PreparedStatement ps;
	int rowcount;
	static ResultSet rs,rs1,rs2;
	public BlCreateAccount() {
		// TODO Auto-generated constructor stub
		dc=new database_connection();
		con=dc.connect();
		
	
	}
	public int insertaccount(ElCreateAccount el){
		String ins="INSERT INTO `tbl_account` (`accno`, `userid`, `acctypeid`, `balance`) VALUES (?,?,?,?)";
		try{
			ps=con.prepareStatement(ins);
			ps.setInt(1,el.getAccno());
			ps.setInt(2, el.getUserid1());
			ps.setInt(3, el.getCtypeid());
			ps.setDouble(4, el.getBalance());
			
			
		rowcount=ps.executeUpdate();
			
		}
		catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		return rowcount;
	}

}
