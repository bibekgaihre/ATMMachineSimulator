package businessLayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import databaseLayer.database_connection;
import entityLayer.ElDeposit;

public class BlDeposit {
	database_connection dc;
	Connection con;
	PreparedStatement ps,ps1;
	int rowcount;
	
	public BlDeposit() {
		// TODO Auto-generated constructor stub
		dc=new database_connection();
		con=dc.connect();
	}
	public int depositBalance(ElDeposit el){
	String ins="UPDATE `tbl_account` SET `balance` = '"+el.getBalance3()+"' WHERE `tbl_account`.`accno` = '"+el.getAccountno()+"'";
	String ins1="INSERT INTO `tbl_transaction` (`transactiontype`, `accno`, `transaction_amount`) VALUES (?,?,?)";
	try{
		ps=con.prepareStatement(ins);
		ps1=con.prepareStatement(ins1);
		
		ps1.setString(1, "Deposit");
		ps1.setInt(2, el.getAccountno());
		ps1.setDouble(3, el.getBalance2());
		
		rowcount=ps.executeUpdate();
		rowcount=ps1.executeUpdate();
	}
	catch(SQLException ex){
		System.out.println(ex.getMessage());
	}
	return rowcount;
}

	public int depositOverdraft(ElDeposit el){
		String ins="UPDATE `tbl_account` SET `overdraft` = '"+el.getBalance3()+"' WHERE `tbl_account`.`accno` = '"+el.getAccountno()+"'";
		String ins1="INSERT INTO `tbl_transaction` (`transactiontype`, `accno`, `transaction_amount`) VALUES (?,?,?)";
		try{
			ps=con.prepareStatement(ins);
			ps1=con.prepareStatement(ins1);
			
			ps1.setString(1, "Deposit Overdraft");
			ps1.setInt(2, el.getAccountno());
			ps1.setDouble(3, el.getBalance2());
			
			rowcount=ps.executeUpdate();
			rowcount=ps1.executeUpdate();
		}
		catch(SQLException ex){
			System.out.println(ex.getMessage());
		}
		return rowcount;
	}
}
