package businessLayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import databaseLayer.database_connection;

import entityLayer.ElEditProfile;

public class BlEditProfile {
	database_connection dc;
	Connection con;
	PreparedStatement ps;
	int rowcount;
	public BlEditProfile() {
		// TODO Auto-generated constructor stub
		dc=new database_connection();
		con=dc.connect();
	}
	public int updateprofile(ElEditProfile ee){
		String updateprofile="UPDATE `tbl_user` SET `name` = '"+ee.getUser()+"', `address` = '"+ee.getAddress()+"', `contactno` = '"+ee.getContactno()+"', `email` = '"+ee.getEmail()+"', `pin` = '"+ee.getPin()+"' WHERE `tbl_user`.`userid` = '"+ee.getUserid()+"'";
		try{
			ps=con.prepareStatement(updateprofile);
			rowcount=ps.executeUpdate();
		}
		catch(SQLException ex){
			System.out.println(ex.getMessage());
		}
		return rowcount;
	}

}
