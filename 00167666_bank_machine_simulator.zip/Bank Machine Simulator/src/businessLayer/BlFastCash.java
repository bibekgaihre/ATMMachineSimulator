package businessLayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import databaseLayer.database_connection;
import entityLayer.ElFastCash;
import entityLayer.ElWithdraw;

public class BlFastCash {
	database_connection dc;
	Connection con;
	PreparedStatement ps,ps1;
	int rowcount;
	public BlFastCash() {
		// TODO Auto-generated constructor stub
		dc=new database_connection();
		con=dc.connect();
	}

	public int fastcashBalance(ElFastCash efc){
		String ins="UPDATE `tbl_account` SET `balance` = '"+efc.getBalance3()+"' WHERE `tbl_account`.`accno` = '"+efc.getAccountno()+"'";
		String ins1="INSERT INTO `tbl_transaction` (`transactiontype`, `accno`, `transaction_amount`) VALUES (?,?,?)";
		try{
			ps=con.prepareStatement(ins);
			ps1=con.prepareStatement(ins1);
			
			ps1.setString(1, "Withdraw");
			ps1.setInt(2, efc.getAccountno());
			ps1.setDouble(3, efc.getBalance2());
			
			rowcount=ps.executeUpdate();
			rowcount=ps1.executeUpdate();
		}
		catch(SQLException ex){
			System.out.println(ex.getMessage());
		}
		return rowcount;
	}
}
