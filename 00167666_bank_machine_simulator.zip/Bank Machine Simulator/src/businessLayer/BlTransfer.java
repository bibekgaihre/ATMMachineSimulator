package businessLayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import databaseLayer.database_connection;
import entityLayer.ElDeposit;
import entityLayer.ElTransfer;

public class BlTransfer {
	database_connection dc;
	Connection con;
	PreparedStatement ps,ps1,ps2,ps3;
	int rowcount;
	ResultSet rs;
	public BlTransfer() {
		// TODO Auto-generated constructor stub
		dc=new database_connection();
		con=dc.connect();
	}
	public int transferBalance(ElTransfer el){
		String update1="UPDATE `tbl_account` SET `balance` = '"+el.getBalance3()+"' WHERE `tbl_account`.`accno` = '"+el.getAccountno()+"'";
		String update2="UPDATE `tbl_account` SET `balance` = '"+el.getTranstotal()+"' WHERE `tbl_account`.`accno` = '"+el.getDesaccountno()+"'";
		String ins1="INSERT INTO `tbl_transaction` (`transactiontype`, `accno`, `transferaccno` , `transaction_amount`) VALUES (?,?,?,?)";
		try{
			ps=con.prepareStatement(update1);
			ps1=con.prepareStatement(ins1);
			ps2=con.prepareStatement(update2);
			ps1.setString(1, "Transfer");
			ps1.setInt(2, el.getAccountno());
			ps1.setInt(3,el.getDesaccountno());
			ps1.setDouble(4, el.getBalance2());
			
			rowcount=ps.executeUpdate();
			
			rowcount=ps1.executeUpdate();
			rowcount=ps2.executeUpdate();
		}
		catch(SQLException ex){
			System.out.println(ex.getMessage());
		}
		return rowcount;
	}

	public ResultSet searchBalance(ElTransfer el){
		String search="SELECT * from `tbl_account` WHERE `accno`='"+el.getDesaccountno()+"'";
		try{
			ps3=con.prepareStatement(search);
			rs=ps3.executeQuery();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		
		return rs;
	}
	
}
