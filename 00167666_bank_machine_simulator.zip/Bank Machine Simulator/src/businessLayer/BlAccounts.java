package businessLayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;

import databaseLayer.database_connection;
import entityLayer.ElAccounts;
import entityLayer.ElHome;
import presentationLayer.Accounts;
import presentationLayer.Dashboard;

public class BlAccounts{
	database_connection dc;
	Connection con;
	PreparedStatement ps;
	int rowcount;
	static ResultSet rs,rs1;
	String[] account;
	public BlAccounts() {
		// TODO Auto-generated constructor stub
		dc=new database_connection();
		con=dc.connect();
	}

	
	public ResultSet checkAccount(ElAccounts el){
		String check="SELECT * FROM tbl_account WHERE userid='"+el.getUserid()+"' AND acctypeID=1" ;
		try{
			ps=con.prepareStatement(check);
			
			rs=ps.executeQuery();
				
				}
		catch(SQLException ex){
			System.out.println(ex.getMessage());
		}
		return rs;
	}
	
	/*public String[] getassociatedacc(ElAccounts el){
		int length=0;
	
		try{
			String check="SELECT * FROM tbl_account WHERE userid='"+el.getUserid()+"' AND acctypeID=1" ;
			ps=con.prepareStatement(check);
			 rs1=ps.executeQuery();
			rs1.last();
			length=rs1.getRow();
			rs1.beforeFirst();
			String[] account1=new String[length];
			length=0;
			while(rs1.next()){
				account1[length]=""+rs1.getInt("accno");
				length++;
			}
			account=Arrays.copyOf(account1, account1.length);
		}
		catch(SQLException ex){
			System.out.println(ex.getMessage());
		}
		return account;
	}*/
	
	
	public ResultSet checkAccount1(ElAccounts el){
		String check="SELECT * FROM tbl_account WHERE userid='"+el.getUserid()+"' AND acctypeID=2" ;
		try{
			ps=con.prepareStatement(check);
			
			rs=ps.executeQuery();
				
				}
		catch(SQLException ex){
			System.out.println(ex.getMessage());
		}
		return rs;
	}
	public ResultSet checkAccount2(ElAccounts el){
		String check="SELECT * FROM tbl_account WHERE userid='"+el.getUserid()+"' AND acctypeID=3" ;
		try{
			ps=con.prepareStatement(check);
			
			rs=ps.executeQuery();
				
				}
		catch(SQLException ex){
			System.out.println(ex.getMessage());
		}
		return rs;
	}
}
