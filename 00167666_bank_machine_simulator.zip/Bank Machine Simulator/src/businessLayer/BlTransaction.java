package businessLayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import databaseLayer.database_connection;
import entityLayer.ElTransaction;

public class BlTransaction {
	database_connection dc;
	Connection con;
	PreparedStatement ps;
	int rowcount;
	static ResultSet rs;
	public BlTransaction() {
		// TODO Auto-generated constructor stub
		dc=new database_connection();
		con=dc.connect();
	}
	public ResultSet showTransaction(ElTransaction el){
		String show="Select transactiontype,transferaccno,transaction_amount,date FROM tbl_transaction WHERE accno='"+el.getAccno()+"' ";
		try{
			
			ps=con.prepareStatement(show);
			rs=ps.executeQuery();
		}
		catch(SQLException ex){
			System.out.println(ex.getMessage());

		}
		
		return rs;
	}
	
	
}
