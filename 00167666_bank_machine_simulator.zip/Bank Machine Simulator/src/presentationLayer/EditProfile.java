package presentationLayer;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.plaf.basic.BasicInternalFrameUI;

import businessLayer.BlEditProfile;
import entityLayer.ElEditProfile;
import entityLayer.Global;

public class EditProfile {

	

	private JLabel lbluser,lbladdress,lblemail,lblcontact,lblpin;
	private JTextField txtuser,txtaddress,txtemail,txtcontact;
	private JPasswordField txtpin;
	private JFrame f;
	private JInternalFrame dep;
	private JPanel panelup,paneldown;
	private JPanel panel1,panel2,panel3;
	private JLabel label1,label2;
	private JTextField txtuserf;
	private Font font1,font2,font3,font4;
	private JButton btndash,btnsave;
	private Font font5;
	public EditProfile() {
		font2=new Font("Courier New", Font.BOLD, 30);
		font4=new Font("Calibri", Font.PLAIN, 20);
		font3=new Font("Segoe UI Semibold",Font.PLAIN,25);
		font1=new Font("Century Gothic",Font.PLAIN,16);
		f=new JFrame();
		f.setTitle("Close Account");
		f.setSize(700, 650);
		f.setDefaultCloseOperation(3);
		f.setLocationRelativeTo(null);
		f.setVisible(true);
		dep=new JInternalFrame();
		dep.setLayout(null);
		
		
		label1=new JLabel("Edit Profile");
		label2=new JLabel("Bank Machine");
		
		btndash=new JButton("Dashboard");
		btnsave=new JButton("Save");
		btndash.setBackground(new Color(160, 5, 34));
		btndash.setForeground(Color.WHITE);
		btndash.setFont(font3);
		btnsave.setBackground(new Color(160, 5, 34));
		btnsave.setForeground(Color.WHITE);
		btnsave.setFont(font3);
		btndash.setBorder(null);
		btnsave.setBorder(null);
		
		txtuserf=new JTextField();
		txtuserf.setBounds(500, 20, 150, 30);
		txtuserf.setEditable(false);
		txtuserf.setBorder(null);
		txtuserf.setText(String.valueOf(Global.user_id));
		lbluser=new JLabel("Username");
		lbladdress=new JLabel("Address");
		lblcontact=new JLabel("Contact No.");
		lblemail=new JLabel("Email");
		lblpin=new JLabel("PIN");
		lbluser.setBounds(100, 10, 100, 40);
		lbladdress.setBounds(100, 50, 100, 40);
		lblcontact.setBounds(100, 90, 100, 40);
		lblemail.setBounds(100, 130, 100, 40);
		lblpin.setBounds(100, 170, 150, 40);
		lbluser.setFont(font4);
		lbladdress.setFont(font4);
		lblcontact.setFont(font4);
		lblemail.setFont(font4);
		lblpin.setFont(font4);
		
		
		
		txtuser=new JTextField();
		txtaddress=new JTextField();
		txtcontact=new JTextField();
		txtemail=new JTextField();
		txtpin=new JPasswordField();
		txtuser.setBounds(370, 10, 280, 40);
		txtaddress.setBounds(370, 50, 280, 40);
		txtcontact.setBounds(370, 90, 280, 40);
		txtemail.setBounds(370, 130, 280, 40);
		txtpin.setBounds(370, 170, 280, 40);
		txtuser.setFont(font1);
		txtaddress.setFont(font1);
		txtcontact.setFont(font1);
		txtemail.setFont(font1);
		txtpin.setFont(font1);
		
		
		
		panel1=new JPanel();
		panel1.setLayout(null);
		panel2=new JPanel();
		panel2.setLayout(null);
		panel3=new JPanel();
		panel3.setLayout(null);
		panel1.setBounds(0, 0, 700, 105);
		panel2.setBounds(0, 110, 700, 400);
		panel3.setBounds(0, 515, 700, 105);
		
		panelup=new JPanel();
		paneldown=new JPanel();
		panelup.setLayout(null);
		paneldown.setLayout(new GridLayout(1,2,15,15));
		panelup.setBounds(0, 0, 700, 300);
		paneldown.setBounds(0, 300, 700, 100);
		
		panelup.setBackground(Color.WHITE);
		paneldown.setBackground(Color.WHITE);
		
		label1.setForeground(Color.WHITE);
		label1.setBounds(10, 0, 270, 110);
		label1.setFont(font2);
		label2.setForeground(Color.WHITE);
		label2.setBounds(10, 10, 230, 80);
		label2.setFont(font2);
		
		
		panel1.setBackground(new Color(58,57,57));
		panel2.setBackground(Color.WHITE);
		panel3.setBackground(new Color(58,57,57));
		
		//title bar of internal frame is set null
		BasicInternalFrameUI bi = (BasicInternalFrameUI)dep.getUI();
		bi.setNorthPane(null);
		
		
		panelup.add(lbluser);
		panelup.add(lbladdress);
		panelup.add(lblcontact);
		panelup.add(lblemail);
		panelup.add(lblpin);
		panelup.add(txtuser);
		panelup.add(txtaddress);
		panelup.add(txtcontact);
		panelup.add(txtemail);
		panelup.add(txtpin);
		paneldown.add(btndash);
		paneldown.add(btnsave);
		panel2.add(panelup);
		panel2.add(paneldown);
		panel1.add(label1);
		panel1.add(txtuserf);
		panel3.add(label2);
		
		dep.add(panel1);
		dep.add(panel2);
		dep.add(panel3);
		
		dep.setVisible(true);
		dep.setSize(700,650);
		f.add(dep);
		f.setResizable(false);
		
		innereditprofile ip=new innereditprofile();
		btndash.addActionListener(ip);
		btnsave.addActionListener(ip);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new EditProfile();
	}
	
	public class innereditprofile implements ActionListener{
		ElEditProfile ee=new ElEditProfile();
		BlEditProfile be=new BlEditProfile();
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if(e.getSource()==btndash){
				f.dispose();
				new Dashboard();
				
			}
			if(e.getSource()==btnsave){
				
					int option;
					option=JOptionPane.showConfirmDialog(null, "To save changes,you need to logout"+"\n"+"Are you sure you want to Logout", "Save changes", JOptionPane.YES_NO_OPTION,1);
					if(option==0){
						int userid;
						String user,address,email,pin;
						int contact;
						userid=Integer.parseInt(txtuserf.getText());
						
						user=txtuser.getText();
						address=txtaddress.getText();
						email=txtemail.getText();
						pin=String.valueOf(txtpin.getPassword());
						contact=Integer.parseInt(txtcontact.getText());
						ee.setUserid(userid);
						ee.setUser(user);
						ee.setAddress(address);
						ee.setContactno(contact);
						ee.setEmail(email);
						ee.setPin(pin);
						
						int count=be.updateprofile(ee);
						if(count==1){
							JOptionPane.showMessageDialog(null, "Profile Succesfully Updated"+"\n"+"System is exiting");
							f.dispose();
							
						}
						else if(count==0){
							JOptionPane.showMessageDialog(null, "Update Failed");
						}
						
					if(option==1){
						
					}
				}
				
			}
		}
		
	}
}
