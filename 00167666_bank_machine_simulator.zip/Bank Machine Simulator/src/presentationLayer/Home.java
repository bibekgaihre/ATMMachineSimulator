package presentationLayer;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.nio.channels.ShutdownChannelGroupException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Random;

import javax.swing.*;
import javax.swing.plaf.basic.BasicInternalFrameUI;

import businessLayer.BlCreateAccount;
import businessLayer.BlHome;
import entityLayer.ElCreateAccount;
import entityLayer.ElHome;
import entityLayer.Global;


public class Home {
	private JFrame homeframe;
	private JPanel homepanel1,homepanel2;
	private JButton login,signup;
	private BasicInternalFrameUI ui;
	private JInternalFrame homeinframe,loginframe,signupframe;
	private JLabel bank,machine;
	Font font1,font2,font3;

	public Home(){
		//Now a constructor of class Home is made to setup Properties of JFrame
		
		
		font1=new Font("Courier New", Font.BOLD, 27);
		font2=new Font("Calibri", Font.BOLD, 55);
		
		homeframe=new JFrame();
		homeframe.setTitle("Bank Machine");
		homeframe.setSize(700, 650);
		homeframe.setVisible(true);
		homeframe.setLocationRelativeTo(null);
		homeframe.setDefaultCloseOperation(3);
		
		homeinframe=new JInternalFrame();
		
		homeinframe.setLayout(new GridLayout(1,1));
		
		//two buttons and panels  are created
		login=new JButton("LOGIN");
		signup=new JButton("SIGN UP");
		login.setFont(font1);
		signup.setFont(font1);
		//setting background and foreground color of buttons
		login.setBackground(new Color(251,96,68));
		signup.setBackground(new Color(251,96,68));
		login.setBorder(null);
		signup.setBorder(null);
		login.setForeground(Color.WHITE);
		signup.setForeground(Color.WHITE);
		
		
		//setting labels along with color and font style
		bank=new JLabel("Bank");
		machine=new JLabel("Machine");
		
		
		bank.setForeground(Color.WHITE);
		machine.setForeground(Color.WHITE);
		
		bank.setFont(font2);
		machine.setFont(font2);
		//setting panels
		homepanel1=new JPanel();
		homepanel2=new JPanel();
		homepanel1.setLayout(null);
		homepanel2.setLayout(null);
		
		//setting background color of panels
		homepanel1.setBackground(new Color(58,57,57));
		homepanel2.setBackground(new Color(58,57,57));
		
		//locating buttons and labels
		bank.setBounds(170, 50, 150, 70);
		machine.setBounds(0, 50, 220, 70);
		
		login.setBounds(80, 470, 200, 100);
		signup.setBounds(85, 470, 200, 100);
		
		//adding buttons and labels to panels
		homepanel1.add(bank);
		homepanel2.add(machine);
		homepanel1.add(login);
		homepanel2.add(signup);
		
		homeinframe.add(homepanel1);
		homeinframe.add(homepanel2);
		homeinframe.setResizable(false);
		homeinframe.setDefaultCloseOperation(3);
		homeinframe.setClosable(false);
		homeinframe.setSize(700, 650);
		homeinframe.setVisible(true);
		
		
		//title is set null of internal frame
		BasicInternalFrameUI bi = (BasicInternalFrameUI)homeinframe.getUI();
		bi.setNorthPane(null);
		
		homeinframe.add(homepanel1);
		homeinframe.add(homepanel2);
		
		
		
		homeframe.add(homeinframe);
		homeframe.setResizable(false);
		
		innerHome ih=new innerHome();
		login.addActionListener(ih);
		signup.addActionListener(ih);
		
		
		
		
	}
	
	private JLabel labellog,labeluserid,labelpin;
	private JButton btnlogin,btnsignup;
	private JTextField txtuserid0;
	private JPasswordField txtpin;
	private JPanel panellabel,panelfield;
	public void loginframe(){
		//making a new internal frame,labels and buttons
		loginframe=new JInternalFrame();
		loginframe.setLayout(new GridLayout(1,1));
		labellog=new JLabel("LOGIN");
		labeluserid=new JLabel("User ID");
		labelpin=new JLabel("Pin No.");
		txtuserid0=new JTextField();
		txtpin=new JPasswordField();
		txtpin.addKeyListener(new KeyAdapter() {
		    public void keyTyped(KeyEvent e) {
		        char c = e.getKeyChar();
		        if (!((c >= '0') && (c <= '9') ||
		           (c == KeyEvent.VK_BACK_SPACE) ||
		           (c == KeyEvent.VK_DELETE))) {
		          
		          e.consume();
		        }
		      }});
		txtuserid0.addKeyListener(new KeyAdapter() {
		    public void keyTyped(KeyEvent e) {
		        char c = e.getKeyChar();
		        if (!((c >= '0') && (c <= '9') ||
		           (c == KeyEvent.VK_BACK_SPACE) ||
		           (c == KeyEvent.VK_DELETE))) {
		          
		          e.consume();
		        }
		      }});
	
		btnlogin=new JButton("LOGIN");
		btnsignup=new JButton("SIGN UP");
		panellabel=new JPanel();
		panelfield=new JPanel();
		panellabel.setLayout(null);
		panelfield.setLayout(null);
		panellabel.setBackground(new Color(58,57,57));
		panelfield.setBackground(new Color(58,57,57));
		//setting bounds, colors and fonts of labels 
		labellog.setBounds(50, 70, 200, 80);
		labellog.setForeground(Color.WHITE);
		font2=new Font("Calibri", Font.BOLD, 55);
		labellog.setFont(font2);
		labeluserid.setBounds(50, 200, 230, 80);
		labeluserid.setForeground(Color.WHITE);
		font3=new Font("Calibri", Font.BOLD, 40);
		labeluserid.setFont(font3);
		labelpin.setBounds(50, 300, 230, 80);
		labelpin.setForeground(Color.WHITE);
		font3=new Font("Calibri", Font.BOLD, 40);
		labelpin.setFont(font3);
		
		//setting bounds, colors and fonts of buttons 
		btnlogin.setBounds(80, 470, 200, 100);
		btnsignup.setBounds(85, 470, 200, 100);
		btnlogin.setBackground(new Color(251,96,68));
		btnsignup.setBackground(new Color(251,96,68));
		btnlogin.setBorder(null);
		btnsignup.setBorder(null);
		btnlogin.setForeground(Color.WHITE);
		btnsignup.setForeground(Color.WHITE);
		btnlogin.setFont(font1);
		btnsignup.setFont(font1);
		
		panellabel.add(labellog);
		panellabel.add(labeluserid);
		panellabel.add(labelpin);
		panellabel.add(btnsignup);
		panelfield.add(txtuserid0);
		panelfield.add(txtpin);
		panelfield.add(btnlogin);
		
		//setting bounds,colors and fonts of text boxes
		txtuserid0.setBounds(60, 200, 250, 80);		
		txtpin.setBounds(60,300,250,80);
		txtuserid0.setBorder(null);
		txtpin.setBorder(null);
		txtuserid0.setFont(font3);
		txtpin.setFont(font3);
		//title bar of internal frame is set null
				BasicInternalFrameUI bi = (BasicInternalFrameUI)loginframe.getUI();
				bi.setNorthPane(null);
		
		
		//defining internal frame
		loginframe.setResizable(false);
		loginframe.setSize(700, 650);
		loginframe.setVisible(true);
		loginframe.setClosable(false);
		
		loginframe.add(panellabel);
		loginframe.add(panelfield);
		homeframe.add(loginframe);
		homeinframe.dispose();
		
		
		innerHome ih=new innerHome();
		btnsignup.addActionListener(ih);
		
		btnlogin.addActionListener(ih);
		
	}
	
	JPanel panellabel1,panelfield1;
	JLabel lblsignup,lbluserid,lbluser,lbladdress,lblcontact,lblemail,lblpin,lblpin1;
	JTextField txtuserid,txtuser,txtaddress,txtcontact,txtemail;
	JPasswordField pin,pin1;
	JButton btnsubmit,btnlogin1;

	public void signupframe(){
		
		signupframe=new JInternalFrame();
		signupframe.setLayout(new GridLayout(1,1));
		panellabel1=new JPanel();
		panelfield1=new JPanel();
		panellabel1.setLayout(null);
		panelfield1.setLayout(null);
		panellabel1.setBackground(new Color(58,57,57));
		panelfield1.setBackground(new Color(58,57,57));
		btnlogin=new JButton("login");

		//designing labels,buttons in a panel
		lblsignup=new JLabel("Create account");
		lbluserid=new JLabel("User ID");
		lbluser=new JLabel("Full Name");
		lbladdress=new JLabel("Address");
		lblcontact=new JLabel("Contact No.");
		lblemail=new JLabel("Email");
		lblpin=new JLabel("PIN");
		lblpin1=new JLabel("Re-Enter PIN");
		
		btnsubmit=new JButton("NEXT");
		lblsignup.setBounds(80, 0, 200, 90);
		lbluserid.setBounds(95, 100, 200, 30);
		lbluser.setBounds(95, 140, 200, 30);
		lbladdress.setBounds(95, 180, 200, 30);
		lblcontact.setBounds(95, 220, 200, 30);
		lblemail.setBounds(95, 260, 200, 30);
		lblpin.setBounds(95, 300, 200, 30);
		lblpin1.setBounds(95,340, 200, 30);
		
		btnsubmit.setBounds(85, 470, 200, 100);
		
		
		
		//designing text field,buttons in another panel
	
		
		
		txtuserid=new JTextField();
		Random ran=new Random();
		int num=ran.nextInt(10000)+1;
		String value=String.valueOf(num);
		txtuserid.setText(value);
		txtuserid.setEditable(false);
		
		txtuser=new JTextField();
		txtuser.addKeyListener(new KeyAdapter() {
		    public void keyTyped(KeyEvent e) {
		        char c = e.getKeyChar();
		        if (!((c >= 'a') && (c <= 'z') ||(c>='A') && (c<='Z') ||
		           (c == KeyEvent.VK_BACK_SPACE) || (c==KeyEvent.VK_SPACE) ||
		           (c == KeyEvent.VK_DELETE))) {
		          
		          e.consume();
		        }
		      }});
		txtaddress=new JTextField();
		txtaddress.addKeyListener(new KeyAdapter() {
		    public void keyTyped(KeyEvent e) {
		        char c = e.getKeyChar();
		        if (!((c >= 'a') && (c <= 'z') ||(c>='A') && (c<='Z') ||
		           (c == KeyEvent.VK_BACK_SPACE) ||
		           (c == KeyEvent.VK_DELETE))) {
		          
		          e.consume();
		        }
		      }});
		txtcontact=new JTextField();
		txtcontact.addKeyListener(new KeyAdapter() {
		    public void keyTyped(KeyEvent e) {
		        char c = e.getKeyChar();
		        if (!((c >= '0') && (c <= '9') ||
		           (c == KeyEvent.VK_BACK_SPACE) ||
		           (c == KeyEvent.VK_DELETE))) {
		          
		          e.consume();
		        }
		      }});
		txtemail=new JTextField();
		pin=new JPasswordField();
		
		pin1=new JPasswordField();
		
		btnlogin1=new JButton("LOGIN");
		txtuserid.setBounds(80, 100, 200, 30);
		txtuser.setBounds(80, 140, 200, 30);
		txtaddress.setBounds(80, 180, 200, 30);
		txtcontact.setBounds(80, 220, 200, 30);
		txtemail.setBounds(80, 260, 200, 30);
		pin.setBounds(80, 300, 200, 30);
		pin1.setBounds(80,340, 200, 30);
		
		btnlogin1.setBounds(80, 470, 200, 100);
		
		
		//setting font and color of components
		lblsignup.setForeground(Color.WHITE);
		font3=new Font("Courier New", Font.BOLD, 27);
		font2=new Font("Calibri", Font.BOLD, 30);
		lblsignup.setFont(font2);
		font1=new Font("Calibri", Font.PLAIN, 20);
		lbluserid.setForeground(Color.WHITE);
		lbluserid.setFont(font1);
		lbluser.setForeground(Color.WHITE);
		lbluser.setFont(font1);
		lbladdress.setForeground(Color.WHITE);
		lbladdress.setFont(font1);
		lblcontact.setForeground(Color.WHITE);
		lblcontact.setFont(font1);
		lblemail.setForeground(Color.WHITE);
		lblemail.setFont(font1);
		lblpin.setForeground(Color.WHITE);
		lblpin.setFont(font1);
		lblpin1.setForeground(Color.WHITE);
		lblpin1.setFont(font1);
		
		btnsubmit.setBackground(new Color(251,96,68));
		btnsubmit.setForeground(Color.WHITE);
		btnsubmit.setFont(font3);
		btnsubmit.setBorder(null);
		btnsubmit.setEnabled(false);
		btnlogin1.setBackground(new Color(251,96,68));
		btnlogin1.setForeground(Color.WHITE);
		btnlogin1.setFont(font3);
		btnlogin1.setBorder(null);
		txtuserid.setBorder(null);
		txtuserid.setFont(font1);
		txtuser.setBorder(null);
		txtuser.setFont(font1);
		txtaddress.setBorder(null);
		txtaddress.setFont(font1);
		txtcontact.setBorder(null);
		txtcontact.setFont(font1);
		txtemail.setBorder(null);
		txtemail.setFont(font1);
		pin.setBorder(null);
		pin1.setFont(font1);
		innerkeys iks=new innerkeys();
		pin.addKeyListener(iks);
	pin1.addKeyListener(iks);	
	
		//adding components to panels
		panellabel1.add(lblsignup);
		panellabel1.add(lbluserid);
		panellabel1.add(lbluser);
		panellabel1.add(lbladdress);
		panellabel1.add(lblcontact);
		panellabel1.add(lblemail);
		panellabel1.add(lblpin);
		panellabel1.add(lblpin1);
		
		panellabel1.add(btnlogin1);
		panelfield1.add(txtuserid);
		panelfield1.add(txtuser);
		panelfield1.add(txtaddress);
		panelfield1.add(txtcontact);
		panelfield1.add(txtemail);
		panelfield1.add(pin);
		panelfield1.add(pin1);
	
		panelfield1.add(btnsubmit);
		//title bar of internal frame is set null
		BasicInternalFrameUI bi = (BasicInternalFrameUI)signupframe.getUI();
		bi.setNorthPane(null);
		
		signupframe.setResizable(false);
		signupframe.setSize(700, 650);
		signupframe.setVisible(true);
		signupframe.setClosable(false);
		
		
		
		signupframe.add(panellabel1);
		signupframe.add(panelfield1);
		homeframe.add(signupframe);
		homeinframe.dispose();
		innerHome ih=new innerHome();
		btnsubmit.addActionListener(ih);
		btnlogin1.addActionListener(ih);
	}
	
	
	public static void main(String args[]){
		new Home();
		
		
	}


public class innerHome implements ActionListener{
	ElCreateAccount el=new ElCreateAccount();
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==btnlogin1){
			Home h=new Home();
			h.loginframe();
			homeinframe.dispose();
			homeframe.dispose();
		}
		if(e.getSource()==login){
			loginframe();
			homeinframe.dispose();
		}
		else if(e.getSource()==signup){
			signupframe();
			homeinframe.dispose();
		
		
			
		}
		else if(e.getSource()==btnsignup){
			Home h=new Home();
			h.signupframe();
			homeinframe.dispose();
			homeframe.dispose();
		}
		
		else if(e.getSource()==btnlogin){
			int userid;
			String pina;
			if(txtuserid0.getText().isEmpty()){
				JOptionPane.showMessageDialog(null, "Please Enter User ID", "Userid not inserted", JOptionPane.WARNING_MESSAGE);
				return;
				}
			
			
			userid=Integer.parseInt(txtuserid0.getText());
			pina=String.valueOf(txtpin.getPassword());
			
			if(String.valueOf(txtpin.getPassword()).isEmpty()){
				JOptionPane.showMessageDialog(null, "Please Enter Pin", "Pin not inserted", JOptionPane.WARNING_MESSAGE);
				return;
				}
			
			
			
			
			if(txtpin.getPassword().equals("")){
				JOptionPane.showMessageDialog(null, "Pin not inserted", "Failed", JOptionPane.WARNING_MESSAGE);
				return;
				} 
			//creating object of entity layer and exporting the value
			ElHome el1=new ElHome();
			el1.setUserid(userid);
			el1.setPin(pina);
			
			//creating object of business layer by importing it
			
			
			
			 
			
			BlHome bl1=new BlHome();
			ResultSet res=bl1.checkData(el1);
			
			
			
			
			try {
				if(res.next()){
					Global.user_id=res.getInt("userid");
					Global.username=res.getString("name");
					Global.address=res.getString("address");
					Global.email=res.getString("email");
					Global.pin=res.getString("pin");
					
					JOptionPane.showMessageDialog(null, "login successfull ");
					new Accounts();
					
					
					
					
					homeframe.dispose();
					
				}
				

				
		}
			
	
				catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(userid!=Global.user_id || !pina.equals(Global.pin) ){
				JOptionPane.showMessageDialog(null, "User or Pin is incorrect"+"\n"+"Please Enter Correctly", "Access Denied", JOptionPane.WARNING_MESSAGE);
				
				return;
			}
			
			
			
			
			
			
		
			
			
			
			
			
			
			
			
		}
		
		
		
		else if(e.getSource()==btnsubmit){
			
				
		
			int userid;
			String username,address,contactno,email;
			String pin,pin1;
		
			userid=Integer.parseInt(txtuserid.getText());
			username=txtuser.getText();
			address=txtaddress.getText();
			contactno=txtcontact.getText();
			email=txtemail.getText();
			
			
			
			
			
			pin=String.valueOf(Home.this.pin.getPassword());
			pin1=String.valueOf(Home.this.pin1.getPassword());
			
			if(!pin.equals(pin1)){
				JOptionPane.showMessageDialog(null, "pin didn't matched");
				return;
			}
			if(txtuser.getText().isEmpty()){
				JOptionPane.showMessageDialog(null, "Full name not inserted", "Failed", JOptionPane.WARNING_MESSAGE);
				return;
				} 
			if(txtaddress.getText().isEmpty()){
				JOptionPane.showMessageDialog(null, "Address not inserted", "Failed", JOptionPane.WARNING_MESSAGE);
				return;

				} 
			if(txtcontact.getText().isEmpty()){
				JOptionPane.showMessageDialog(null, "Contact not inserted", "Failed", JOptionPane.WARNING_MESSAGE);
				return;

				} 
			if(txtemail.getText().isEmpty()){
				JOptionPane.showMessageDialog(null, "Email not inserted", "Failed", JOptionPane.WARNING_MESSAGE);
			
				return;

				} 
			if(pin1.equals("")){
				JOptionPane.showMessageDialog(null, "Pin not inserted", "Failed", JOptionPane.WARNING_MESSAGE);
				return;

			}
			if(pin.equals("")){
				JOptionPane.showMessageDialog(null, "Pin not inserted", "Failed", JOptionPane.WARNING_MESSAGE);
				return;
			}
		
			else if(pin.equals(pin1)){
				
				ElHome el=new ElHome();
				el.setUserid(userid);
				el.setUsername(username);
				el.setAddress(address);
				el.setContactno(contactno);
				el.setEmail(email);
				el.setPin(pin);
				
			
					
				BlHome bl=new BlHome();
				int count=bl.insertData(el);
				if(count==1){
					Global.user_id=el.getUserid();
					Global.address=el.getAddress();
					Global.email=el.getEmail();
					Global.username=el.getUsername();
					JOptionPane.showMessageDialog(null,"Congratulations you have been Registered"+"\n"+"Your Current user ID is "+Global.user_id );
					
					
					new Createacc();
					homeframe.dispose();
				}
				if(count==0){
					JOptionPane.showMessageDialog(null, "User Creation Failed"+"\n"+"Try Again Later");
				}
					}
						
						}

			}
		
		
			



			
			
		}
		
		
	
		class innerkeys implements KeyListener{

			@Override
			public void keyTyped(KeyEvent e) {
				if(!String.valueOf(pin.getPassword()).equals(String.valueOf(pin1.getPassword()))){
					btnsubmit.setEnabled(false);
				}
			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
			}

			
			    @Override
			    public void keyReleased(KeyEvent e) {
			    	// TODO Auto-generated method stub
					
			        if(String.valueOf(pin.getPassword()).equals(String.valueOf(pin1.getPassword()))){
			        	btnsubmit.setEnabled(true);
			    
			    }
			        if(!String.valueOf(pin.getPassword()).equals(String.valueOf(pin1.getPassword()))){
						btnsubmit.setEnabled(false);
					}
			
		}
	}
}
	
	
	
	
	
	
	
	
	
	
	
	
	

