package presentationLayer;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.plaf.basic.BasicInternalFrameUI;

import businessLayer.BlAccounts;
import businessLayer.BlDeposit;
import businessLayer.BlFastCash;
import businessLayer.BlHome;
import businessLayer.BlTransaction;
import businessLayer.BlTransfer;
import businessLayer.BlWithdraw;
import entityLayer.ElAccounts;
import entityLayer.ElDeposit;
import entityLayer.ElFastCash;
import entityLayer.ElHome;
import entityLayer.ElTransaction;
import entityLayer.ElTransfer;
import entityLayer.ElWithdraw;
import entityLayer.Global;
import net.proteanit.sql.DbUtils;

public class Dashboard {
	private JFrame dashboard;
	private JInternalFrame indashboard;
	private JPanel panel1,panel2,panel3;
	private JButton btnover,btnp,btntr,btncash,btnen,btnw,btnd,btnt;
	private Font font1,font2;
	private JLabel label1,label2;
	private BasicInternalFrameUI ui;
	private JButton btnlogout,btnswitchaccount;
	private JTextField showacc,showdate;
	private JTextField showacctype;
	String[] temp;
	public Dashboard() {
		/*BlAccounts bl=new BlAccounts();
		ElAccounts el=new ElAccounts();*/
		// TODO Auto-generated constructor stub
		font1=new Font("Calibri", Font.PLAIN, 20);
		font2=new Font("Courier New", Font.BOLD, 30);
		font3=new Font("Segoe UI Semibold",Font.PLAIN,20);
		//creating a frame
		dashboard=new JFrame();
		dashboard.setTitle(Global.user);
		dashboard.setSize(700, 650);
		
	
		dashboard.setVisible(true);
		dashboard.setLocationRelativeTo(null);
		dashboard.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	
		//showing current date and time in panel3
		showdate=new JTextField();
		showdate.setBounds(480, 20, 180, 30);
		showdate.setBorder(null);
		DateFormat dateformat=new SimpleDateFormat("yyyy/MM/dd   HH:mm");
		Date date=new Date();
	
		showdate.setText(dateformat.format(date));
		showdate.setEditable(false);
		showdate.setForeground(Color.white);
		showdate.setBackground(new Color(58,57,57));
		showdate.setFont(font3);
		//creating an internal frame
		indashboard=new JInternalFrame();
		
		indashboard.setResizable(false);
		indashboard.setSize(700, 650);
		indashboard.setVisible(true);
		indashboard.setClosable(false);
		indashboard.setDefaultCloseOperation(3);
		indashboard.setLayout(null);
		

			
		//making object of panels to internal frame
		panel1=new JPanel();
		panel2=new JPanel();
		panel3=new JPanel();
		
		panel1.setBounds(0, 0, 700, 105);
		panel2.setBounds(0, 110, 700, 400);
		panel3.setBounds(0, 515, 700, 105);
		panel1.setLayout(null);
		panel2.setLayout(new GridLayout(2,4));
		panel3.setLayout(null);
		
		
		
		panel1.setBackground(new Color(58,57,57));
		panel2.setBackground(new Color(58,57,57));
		panel3.setBackground(new Color(58,57,57));
		

		//setting title bar of internal frame to null
		BasicInternalFrameUI ui = (BasicInternalFrameUI)indashboard.getUI();
		ui.setNorthPane(null);
		
		//labels
		label1=new JLabel("Dashboard");
		
		
		showacc=new JTextField();
		showacc.setText(String.valueOf(Global.account_no));
		showacc.setBounds(500, 50, 160, 30);
		showacc.setFont(font2);
		showacc.setBorder(null);
		showacc.setEditable(false);
		showacctype=new JTextField();
		showacctype.setText(String.valueOf(Global.accounttype));
		showacctype.setBounds(500, 0, 160, 30);
		showacctype.setFont(font1);
		showacctype.setBorder(null);
		showacctype.setEditable(false);
		
		btnlogout=new JButton("Log Out");
		btnlogout.setBounds(300, 20, 100, 50);
		btnlogout.setBackground(new Color(247, 32, 32));
		btnlogout.setForeground(Color.WHITE);
		btnlogout.setBorder(null);
		btnlogout.setFont(font3);
		
		btnswitchaccount=new JButton("Switch Accounts");
		btnswitchaccount.setBounds(250, 28, 200, 50);
		btnswitchaccount.setBackground(new Color(247, 32, 32));
		btnswitchaccount.setForeground(Color.WHITE);
		btnswitchaccount.setBorder(null);
		btnswitchaccount.setFont(font3);
		
		label2=new JLabel("Bank Machine");
		label1.setForeground(Color.WHITE);
		label2.setForeground(Color.WHITE);
		label1.setBounds(10, 0, 220, 110);
		
		label2.setBounds(10, 10, 230, 80);
		label1.setFont(font2);
		label2.setFont(font2);
		
		//making objects of buttons and adding on panels
		btnover=new JButton("Overdraft");
		btnp=new JButton("My Profile");
		btntr=new JButton("Balance Transfer");
		btncash=new JButton("Fast Cash");
		btnen=new JButton("Balance Enquiry");
		btnw=new JButton("Balance Withdrawl");
		btnd=new JButton("Balance Deposit");
		btnt=new JButton("Transactions");
		
		btnover.setBorder(new LineBorder(Color.WHITE, 1));
		btnp.setBorder(new LineBorder(Color.WHITE, 1));
		btntr.setBorder(new LineBorder(Color.WHITE, 1));
		btncash.setBorder(new LineBorder(Color.WHITE, 1));
		btnen.setBorder(new LineBorder(Color.WHITE, 1));
		btnw.setBorder(new LineBorder(Color.WHITE, 1));
		btnd.setBorder(new LineBorder(Color.WHITE, 1));
		btnt.setBorder(new LineBorder(Color.WHITE, 1));
		
		btnover.setForeground(Color.WHITE);
		btnp.setForeground(Color.WHITE);
		btntr.setForeground(Color.WHITE);
		btncash.setForeground(Color.WHITE);
		btnen.setForeground(Color.WHITE);
		btnw.setForeground(Color.WHITE);
		btnd.setForeground(Color.WHITE);
		btnt.setForeground(Color.WHITE);
		
		btnover.setBackground(new Color(251,96,68));
		btnp.setBackground(new Color(237,20,61));
		btntr.setBackground(new Color(95,158,160));
		btncash.setBackground(new Color(58,57,57));
		btnen.setBackground(new Color(96,88,222));
		btnw.setBackground(new Color(121,85,72));
		btnd.setBackground(new Color(33,150,243));
		btnt.setBackground(new Color(51,165,70));
		
		btnover.setFont(font1);
		btnp.setFont(font1);
		btntr.setFont(font1);
		btncash.setFont(font1);
		btnen.setFont(font1);
		btnw.setFont(font1);
		btnd.setFont(font1);
		btnt.setFont(font1);
		
		panel1.add(showacctype);
		panel1.add(btnswitchaccount);
		panel1.add(label1);
		panel1.add(showacc);
		panel3.add(label2);
		panel3.add(showdate);
		panel3.add(btnlogout);
		panel2.add(btnover);
		panel2.add(btnp);
		panel2.add(btntr);
		panel2.add(btncash);
		panel2.add(btnen);
		panel2.add(btnw);
		panel2.add(btnd);
		panel2.add(btnt);
		
		
		//adding components to internal frame
		indashboard.add(panel1);
		indashboard.add(panel2);
		indashboard.add(panel3);
		
		
		//adding internal frame to frame and setting frame Resizable property to null
		dashboard.add(indashboard);
		dashboard.setResizable(false);
		
		innerdashboard id=new innerdashboard();
		btnover.addActionListener(id);
		btnp.addActionListener(id);
		btntr.addActionListener(id);
		btncash.addActionListener(id);
		btnen.addActionListener(id);
		btnw.addActionListener(id);
		btnd.addActionListener(id);
		btnt.addActionListener(id);
		btnlogout.addActionListener(id);
		btnswitchaccount.addActionListener(id);
		

		
	
		
	}
	
	
	private JLabel lbldep,lblp;
	private JButton btndash,btndep;
	private JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12;
	private JTextField txtdep, txtpin;
	private JInternalFrame dep;
	private JLabel lbloverdraftdeposit;
	private JTextField txtoverdraftdeposit;
	private JPanel p1,p2,p3,p4;
	private Font font3,font4;
	public void deposit(){
		font3=new Font("Courier New", Font.BOLD, 25);
		font4=new Font("Calibri", Font.PLAIN, 20);
		dep=new JInternalFrame();
		dep.setLayout(null);
		panel1=new JPanel();
		panel1.setLayout(null);
		panel2=new JPanel();
		panel2.setLayout(null);
		panel3=new JPanel();
		panel3.setLayout(null);
		panel1.setBounds(0, 0, 700, 105);
		panel2.setBounds(0, 110, 700, 400);
		panel3.setBounds(0, 515, 700, 105);
		p1=new JPanel();
		p2=new JPanel();
		p3=new JPanel();
		p4=new JPanel();
		p1.setLayout(null);
		p2.setLayout(null);
		p3.setLayout(null);
		p4.setLayout(new GridLayout(4,3));
		
		showacc=new JTextField();
		showacc.setText(String.valueOf(Global.account_no));
		showacc.setBounds(500, 50, 160, 30);
		showacc.setFont(font2);
		showacc.setBorder(null);
		showacc.setEditable(false);
		showacctype=new JTextField();
		showacctype.setText(String.valueOf(Global.accounttype));
		showacctype.setBounds(500, 0, 160, 30);
		showacctype.setFont(font1);
		showacctype.setBorder(null);
		showacctype.setEditable(false);
		//defining buttons of panel4
		b1=new JButton("1");
		b2=new JButton("2");
		b3=new JButton("3");
		b4=new JButton("4");
		b5=new JButton("5");
		b6=new JButton("6");
		b7=new JButton("7");
		b8=new JButton("8");
		b9=new JButton("9");
		b10=new JButton(".");
		b11=new JButton("0");
		b12=new JButton("<");
		
		
		b1.setBackground(new Color(48,109,61));
		b1.setForeground(Color.WHITE);
		b1.setBorder(new LineBorder(Color.WHITE, 1));
		
		b2.setBackground(new Color(48,109,61));
		b2.setForeground(Color.WHITE);
		b2.setBorder(new LineBorder(Color.WHITE, 1));
		
		b3.setBackground(new Color(48,109,61));
		b3.setForeground(Color.WHITE);
		b3.setBorder(new LineBorder(Color.WHITE, 1));
		
		b4.setBackground(new Color(48,109,61));
		b4.setForeground(Color.WHITE);
		b4.setBorder(new LineBorder(Color.WHITE, 1));
		
		b5.setBackground(new Color(48,109,61));
		b5.setForeground(Color.WHITE);
		b5.setBorder(new LineBorder(Color.WHITE, 1));
		
		b6.setBackground(new Color(48,109,61));
		b6.setForeground(Color.WHITE);
		b6.setBorder(new LineBorder(Color.WHITE, 1));
		
		b7.setBackground(new Color(48,109,61));
		b7.setForeground(Color.WHITE);
		b7.setBorder(new LineBorder(Color.WHITE, 1));
		
		b8.setBackground(new Color(48,109,61));
		b8.setForeground(Color.WHITE);
		b8.setBorder(new LineBorder(Color.WHITE, 1));
		
		b9.setBackground(new Color(48,109,61));
		b9.setForeground(Color.WHITE);
		b9.setBorder(new LineBorder(Color.WHITE, 1));
		
		b10.setBackground(new Color(48,109,61));
		b10.setForeground(Color.WHITE);
		b10.setBorder(new LineBorder(Color.WHITE, 1));
		
		
		b11.setBackground(new Color(48,109,61));
		b11.setForeground(Color.WHITE);
		b11.setBorder(new LineBorder(Color.WHITE, 1));
		
		b12.setBackground(new Color(48,109,61));
		b12.setForeground(Color.WHITE);
		b12.setBorder(new LineBorder(Color.WHITE, 1));
		
		
		p4.add(b1);
		p4.add(b2);
		p4.add(b3);
		p4.add(b4);
		p4.add(b5);
		p4.add(b6);
		p4.add(b7);
		p4.add(b8);
		p4.add(b9);
		p4.add(b10);
		p4.add(b11);
		p4.add(b12);
		
		
		//setting panels and labels
		p1.setBounds(0, 0, 350, 150);
		p1.setBackground(Color.WHITE);
		p2.setBounds(350, 0,350,150 );
		p2.setBackground(Color.WHITE);
		p3.setBounds(0,150, 350, 250);
		p3.setBackground(Color.WHITE);
		p4.setBounds(350, 150, 320, 250);
		p4.setVisible(true);
	
		label1=new JLabel("Balance Deposit");
		label2=new JLabel("Bank Machine");
		label1.setForeground(Color.WHITE);
		label2.setForeground(Color.WHITE);
		label1.setBounds(10, 0, 250, 110);
		label2.setBounds(10, 10, 230, 80);
		label1.setFont(font3);
		label2.setFont(font2);
		
		
		
		
		//defining adding labels.text field and buttons in panel2
		lbldep=new JLabel("Current Balance");
		
		lblp=new JLabel("Enter Sum");
		lbloverdraftdeposit=new JLabel("Overdraft");
		txtdep=new JTextField();
		txtdep.setEditable(false);
		lbloverdraftdeposit.setBounds(50, 50, 100, 40);
		txtdep.setText(String.valueOf(Global.balance));
		txtoverdraftdeposit=new JTextField();
		txtoverdraftdeposit.setText(String.valueOf(Global.overdraft));
		txtoverdraftdeposit.setEditable(false);
		txtoverdraftdeposit.setBounds(160, 50, 150, 40);
		lbloverdraftdeposit.setFont(font4);
		txtoverdraftdeposit.setFont(font4);
		txtpin=new JTextField();
		txtpin.addKeyListener(new KeyAdapter() {
		    public void keyTyped(KeyEvent e) {
		        char c = e.getKeyChar();
		        if (!((c >= '0') && (c <= '9') ||
		           (c == KeyEvent.VK_BACK_SPACE) || (c=='.') ||
		           (c == KeyEvent.VK_DELETE))) {
		          
		          e.consume();
		        }}
		});
		btndash=new JButton("Dashboard");
		btndep=new JButton("Deposit");
		lbldep.setBounds(100, 0, 200, 30);
		
		
	
		
		
		lblp.setBounds(100,45, 150, 30);
		btndash.setBounds(140, 100, 100, 40);
		txtdep.setBounds(100, 0, 150, 30);
		
		
		
		txtpin.setBounds(100, 45, 150, 30);
		lbldep.setFont(font4);
		lblp.setFont(font4);
		txtdep.setFont(font4);
		txtpin.setFont(font4);
		btndep.setBounds(125, 100, 100, 40);
		btndep.setBackground(new Color(251,96,68));
		btndep.setBorder(null);
		btndep.setForeground(Color.WHITE);
		btndash.setBackground(new Color(251,96,68));
	
		btndash.setForeground(Color.WHITE);
		
		btndash.setBorder(null);
		p1.add(lbldep);
		p1.add(lblp);
		p1.add(btndash);
		
		p3.add(txtoverdraftdeposit);
		p3.add(lbloverdraftdeposit);
		p2.add(txtdep);
		p2.add(txtpin);
		p2.add(btndep);
		
		//title bar of internal frame is set null
		BasicInternalFrameUI bi = (BasicInternalFrameUI)dep.getUI();
		bi.setNorthPane(null);
		
		panel1.setBackground(new Color(58,57,57));
		panel2.setBackground(Color.WHITE);
		panel3.setBackground(new Color(58,57,57));
		
		panel1.add(showacctype);
		panel1.add(showacc);
		panel1.add(label1);
		panel2.add(p1);
		panel2.add(p2);
		panel2.add(p3);
		panel2.add(p4);
		panel3.add(label2);
		dep.add(panel1);
		dep.add(panel2);
		dep.add(panel3);
		
		dep.setVisible(true);
		dep.setSize(700,650);
		dashboard.add(dep);
		
		innerbutton ib=new innerbutton();
		b1.addActionListener(ib);
		b2.addActionListener(ib);
		b3.addActionListener(ib);
		b4.addActionListener(ib);
		b5.addActionListener(ib);
		b6.addActionListener(ib);
		b7.addActionListener(ib);
		b8.addActionListener(ib);
		b9.addActionListener(ib);
		b10.addActionListener(ib);
		b11.addActionListener(ib);
		b12.addActionListener(ib);
		
		txtdep.addActionListener(ib);
		
		innerdeposit id=new innerdeposit();
		btndep.addActionListener(id);
		
		innerbuttons ip=new innerbuttons();
		btndash.addActionListener(ip);
		
	}
	
	private JPanel panelup,paneldown;
	private JButton btnchangeacc,btneditprofile,btncloseacc;
	private JLabel lblaccount,lbloverdraft,lblemail1,lbluser,lblacctype;
	private JTextField txtaccount,txtoverdraft,txtemail1,txtuser,txtacctype;
	private Font font5;
	public void profile(){
		
		font3=new Font("Courier New", Font.BOLD, 30);
		font4=new Font("Courier New", Font.BOLD, 30);
		font1=new Font("Calibri",Font.PLAIN,20);
		font5=new Font("Century Gothic",Font.PLAIN,16);
		font2=new Font("Segoe UI Semibold",Font.PLAIN,25);
		dep=new JInternalFrame();
		dep.setLayout(null);
		panel1=new JPanel();
		panel1.setLayout(null);
		panel2=new JPanel();
		panel2.setLayout(null);
		panel3=new JPanel();
		panel3.setLayout(null);
		panel2.setBackground(Color.WHITE);
		panelup=new JPanel();
		paneldown=new JPanel();
		panelup.setLayout(null);
		paneldown.setLayout(new GridLayout(2,2,15,15));
		
		btnchangeacc=new JButton("Change Account");
		btneditprofile=new JButton("Edit Profile");
		btndash=new JButton("Dashboard");
		btncloseacc=new JButton("Close Account");
		lblaccount=new JLabel("Account No");
		lbluser=new JLabel("Username");
		lbloverdraft=new JLabel("Overdraft");
		lblemail1=new JLabel("Email");
		lblacctype=new JLabel("Account Type");
		
		//setting properties of text fields
		txtaccount=new JTextField();
		txtaccount.setText(String.valueOf(Global.account_no));
		txtaccount.setEditable(false);
		txtuser=new JTextField();
		txtuser.setText(Global.username);
		txtuser.setEditable(false);
		txtoverdraft=new JTextField();
		txtoverdraft.setText(String.valueOf(Global.overdraft));
		txtoverdraft.setEditable(false);
		txtemail1=new JTextField();
		txtemail1.setText(Global.email);
		txtemail1.setEditable(false);
		txtacctype=new JTextField();
		txtacctype.setText(Global.accounttype);
		txtacctype.setEditable(false);
		
		panel1.setBounds(0, 0, 700, 105);
		panel2.setBounds(0, 110, 700, 400);
		panel3.setBounds(0, 515, 700, 105);
		panelup.setBounds(0, 0, 700, 250);
		paneldown.setBounds(0, 250, 700, 150);
		lblaccount.setBounds(100, 10, 100, 40);
		lbluser.setBounds(100, 50, 100, 40);
		lbloverdraft.setBounds(100, 90, 100, 40);
		lblemail1.setBounds(100, 130, 100, 40);
		lblacctype.setBounds(100, 170, 150, 40);
		txtaccount.setBounds(370, 10, 280, 40);
		txtuser.setBounds(370, 50, 280, 40);
		txtoverdraft.setBounds(370, 90, 280, 40);
		txtemail1.setBounds(370, 130, 280, 40);
		txtacctype.setBounds(370, 170, 280, 40);
		
		panelup.setBackground(Color.WHITE);
		paneldown.setBackground(Color.WHITE);
		btnchangeacc.setBorder(new LineBorder(Color.WHITE));
		btneditprofile.setBorder(new LineBorder(Color.WHITE));
		btndash.setBorder(new LineBorder(Color.WHITE));
		btncloseacc.setBorder(new LineBorder(Color.WHITE));
		btnchangeacc.setBackground(new Color(160, 5, 34));
		btneditprofile.setBackground(new Color(160, 5, 34));
		btndash.setBackground(new Color(160, 5, 34));
		btncloseacc.setBackground(new Color(160, 5, 34));
		btnchangeacc.setForeground(Color.WHITE);
		btneditprofile.setForeground(Color.WHITE);
		btndash.setForeground(Color.WHITE);
		btncloseacc.setForeground(Color.WHITE);
		btnchangeacc.setFont(font2);
		btneditprofile.setFont(font2);
		btndash.setFont(font2);
		btncloseacc.setFont(font2);
		lblaccount.setFont(font1);
		lbloverdraft.setFont(font1);
		lbluser.setFont(font1);
		lblemail1.setFont(font1);
		lblacctype.setFont(font1);
		txtaccount.setFont(font5);
		txtoverdraft.setFont(font5);
		txtuser.setFont(font5);
		txtemail1.setFont(font5);
		txtacctype.setFont(font5);
		
		
		
		label1=new JLabel("My Profile");
		label2=new JLabel("Bank Machine");
		label1.setForeground(Color.WHITE);
		label2.setForeground(Color.WHITE);
		label1.setBounds(10, 0, 250, 110);
		label2.setBounds(10, 10, 230, 80);
		label1.setFont(font3);
		label2.setFont(font4);
		
		panel1.setBackground(new Color(58,57,57));
		panel2.setBackground(Color.WHITE);
		panel3.setBackground(new Color(58,57,57));
		
		
		
		panelup.add(lblaccount);
		panelup.add(txtaccount);
		panelup.add(lbluser);
		panelup.add(txtuser);
		panelup.add(lbloverdraft);
		panelup.add(txtoverdraft);
		panelup.add(lblemail1);
		panelup.add(txtemail1);
		panelup.add(lblacctype);
		panelup.add(txtacctype);
		paneldown.add(btnchangeacc);
		paneldown.add(btneditprofile);
		paneldown.add(btndash);
		paneldown.add(btncloseacc);
		panel1.add(label1);
		panel3.add(label2);
		panel2.add(panelup);
		panel2.add(paneldown);
		//setting title bar of internal frame to null
		BasicInternalFrameUI ui = (BasicInternalFrameUI)dep.getUI();
		ui.setNorthPane(null);


		dep.add(panel1);
		dep.add(panel2);
		dep.add(panel3);
		dep.setVisible(true);
		dep.setSize(700,650);
		dashboard.add(dep);
		
		innerbuttons ip=new innerbuttons();
		btndash.addActionListener(ip);
		btncloseacc.addActionListener(ip);
		btneditprofile.addActionListener(ip);
		btnchangeacc.addActionListener(ip);
	}
	
	
	private JButton btn50,btn100,btn150,btn200,btn250;
	private JTextField txtshowbalancefastcash;
	public void fastcash(){
		font3=new Font("Courier New", Font.BOLD, 25);
		font4=new Font("Courier New", Font.BOLD, 30);
		font2=new Font("Segoe UI Semibold",Font.PLAIN,25);
		dep=new JInternalFrame();
		dep.setLayout(null);
		panel1=new JPanel();
		panel1.setLayout(null);
		panel2=new JPanel();
		panel2.setLayout(new GridLayout(3,2,35,35));
		panel3=new JPanel();
		panel3.setLayout(null);
		panel1.setBounds(0, 0, 700, 105);
		panel2.setBounds(0, 110, 700, 400);
		panel3.setBounds(0, 515, 700, 105);
		panel2.setBackground(Color.WHITE);
		
		//defining buttons and text field and adding them to panel2
		showacc=new JTextField();
		showacc.setText(String.valueOf(Global.account_no));
		showacc.setBounds(500, 50, 160, 30);
		showacc.setFont(font2);
		showacc.setBorder(null);
		showacc.setEditable(false);
		txtshowbalancefastcash=new JTextField();
		txtshowbalancefastcash.setText(String.valueOf(Global.balance));
		txtshowbalancefastcash.setBounds(300, 50, 160, 30);
		txtshowbalancefastcash.setFont(font2);
		txtshowbalancefastcash.setBorder(null);
		txtshowbalancefastcash.setEditable(false);
		
		btn50=new JButton("� 50");
		btn100=new JButton("� 100");
		btn150=new JButton("� 150");
		btn200=new JButton("� 200");
		btn250=new JButton("� 250");
		btndash=new JButton("Dashboard");
		
		btn50.setBackground(new Color(37, 67, 121));
		btn100.setBackground(new Color(37, 67, 121));
		btn150.setBackground(new Color(37, 67, 121));
		btn200.setBackground(new Color(37, 67, 121));
		btn250.setBackground(new Color(37, 67, 121));
		btndash.setBackground(new Color(37, 67, 121));
		btn50.setBorder(new LineBorder(Color.WHITE, 5));
		btn100.setBorder(new LineBorder(Color.WHITE, 5));
		btn150.setBorder(new LineBorder(Color.WHITE, 5));
		btn200.setBorder(new LineBorder(Color.WHITE, 5));
		btn250.setBorder(new LineBorder(Color.WHITE, 5));
		btndash.setBorder(new LineBorder(Color.WHITE, 5));
		
		btn50.setForeground(Color.WHITE);
		btn100.setForeground(Color.WHITE);
		btn150.setForeground(Color.WHITE);
		btn200.setForeground(Color.WHITE);
		btn250.setForeground(Color.WHITE);
		btndash.setForeground(Color.WHITE);
		btn50.setFont(font2);
		btn100.setFont(font2);
		btn150.setFont(font2);
		btn200.setFont(font2);
		btn250.setFont(font2);
		btndash.setFont(font2);
		panel2.add(btn50);
		panel2.add(btn100);
		panel2.add(btn150);
		panel2.add(btn200);
		panel2.add(btn250);
		panel2.add(btndash);
		
		
		//setting labels 
		label1=new JLabel("Fast Cash");
		label2=new JLabel("Bank Machine");
		label1.setForeground(Color.WHITE);
		label2.setForeground(Color.WHITE);
		label1.setBounds(10, 0, 250, 110);
		label2.setBounds(10, 10, 230, 80);
		label1.setFont(font3);
		label2.setFont(font4);
		
		panel1.setBackground(new Color(58,57,57));
		panel2.setBackground(Color.WHITE);
		panel3.setBackground(new Color(58,57,57));
		
		panel1.add(label1);
		panel3.add(label2);
		panel1.add(showacc);
		panel1.add(txtshowbalancefastcash);
		

		//setting title bar of internal frame to null
				BasicInternalFrameUI ui = (BasicInternalFrameUI)dep.getUI();
				ui.setNorthPane(null);
		
		
		dep.add(panel1);
		dep.add(panel2);
		dep.add(panel3);
		dep.setVisible(true);
		dep.setSize(700,650);
		dashboard.add(dep);
		
		innerbuttons ip=new innerbuttons();
		btndash.addActionListener(ip);
		innerfastcash ifc=new innerfastcash();
		btn100.addActionListener(ifc);
		btn150.addActionListener(ifc);
		btn200.addActionListener(ifc);
		btn250.addActionListener(ifc);
		btn50.addActionListener(ifc);
		
	}
	
	private JButton showtran;
	private JTable tbltran;
	private JScrollPane jp;
	private JPanel panel4;
	private String[] columnNames = {"Transaction Type", "Destination Account no", "Transaction Amount","Date/Time"};
	private String data[][]={};
	public void transactions(){
		font3=new Font("Courier New", Font.BOLD, 25);
		font4=new Font("Calibri", Font.PLAIN, 25);
		dep=new JInternalFrame();
		dep.setLayout(null);
		panel1=new JPanel();
		panel1.setLayout(null);
		panel2=new JPanel();
		panel2.setLayout(null);
		panel3=new JPanel();
		panel3.setLayout(null);
		panel1.setBounds(0, 0, 700, 105);
		panel2.setBounds(0, 110, 700, 400);
		
		panel3.setBounds(0, 515, 700, 105);
		panel4=new JPanel();
		panel4.setBounds(20,50,640,300);
		panel4.setLayout(null);
		
		
		tbltran=new JTable(data,columnNames);
		jp=new JScrollPane();
		
		jp.setViewportView(tbltran);
		jp.getVerticalScrollBar();
		tbltran.setEnabled(false);
		jp.setBounds(0,0,640,300);
		label1=new JLabel("Balance Transfer");
		label2=new JLabel("Bank Machine");
		showtran=new JButton("Show last 100 transactions");
		label1.setForeground(Color.WHITE);
		label2.setForeground(Color.WHITE);
		label1.setBounds(10, 0, 250, 110);
		label2.setBounds(10, 10, 230, 80);
		label1.setFont(font3);
		label2.setFont(font2);
		
		btndash=new JButton("Dashboard");
		btndash.setBounds(110, 0, 100, 40);
		btndash.setBackground(new Color(251,96,68));
		btndash.setBorder(null);
		btndash.setForeground(Color.WHITE);
		
		showtran.setBounds(400, 0, 200, 40);
		showtran.setBackground(new Color(251,96,68));
		showtran.setBorder(null);
		showtran.setForeground(Color.WHITE);
		
		panel1.setBackground(new Color(58,57,57));
		panel2.setBackground(Color.WHITE);
		panel3.setBackground(new Color(58,57,57));

		//setting title bar of internal frame to null
				BasicInternalFrameUI ui = (BasicInternalFrameUI)dep.getUI();
				ui.setNorthPane(null);
				
				//displaying current account number
				showacc=new JTextField();
				showacc.setText(String.valueOf(Global.account_no));
				showacc.setBounds(500, 50, 160, 30);
				showacc.setFont(font2);
				showacc.setBorder(null);
				showacc.setEditable(false);
				
				
				
				
				
				
				
				
				
				
				
				panel1.add(label1);
				panel1.add(showacc);
				panel3.add(label2);
				panel2.add(showtran);
				panel2.add(btndash);
				panel4.add(jp);
				panel2.add(panel4);
				
				
				
				
				dep.add(panel1);
				dep.add(panel2);
				dep.add(panel3);
				
				
				dep.setVisible(true);
				dep.setSize(700,650);
				dashboard.add(dep);
				
				innertran intr=new innertran();
				showtran.addActionListener(intr);
				btndash.addActionListener(intr);
	}
	
	private JLabel lblmoney,lbluseraccno,lblshowbalance;
	private JTextField txtmoney,txtuseraccno,txtshowbalance;
	
	public void transfer(){
		font3=new Font("Courier New", Font.BOLD, 25);
		font4=new Font("Calibri", Font.PLAIN, 15);
		dep=new JInternalFrame();
		dep.setLayout(null);
		panel1=new JPanel();
		panel1.setLayout(null);
		panel2=new JPanel();
		panel2.setLayout(null);
		panel3=new JPanel();
		panel3.setLayout(null);
		panel1.setBounds(0, 0, 700, 105);
		panel2.setBounds(0, 110, 700, 400);
		panel3.setBounds(0, 515, 700, 105);
		p1=new JPanel();
		p2=new JPanel();
		p3=new JPanel();
		p4=new JPanel();
		p1.setLayout(null);
		p2.setLayout(null);
		p3.setLayout(null);
		p4.setLayout(new GridLayout(4,3));
		
		lbluseraccno=new JLabel("Destination Account no.");
		lblmoney=new JLabel("Enter Sum to transfer");
		txtuseraccno=new JTextField();
		txtuseraccno.addKeyListener(new KeyAdapter() {
		    public void keyTyped(KeyEvent e) {
		        char c = e.getKeyChar();
		        if (!((c >= '0') && (c <= '9') ||
		           (c == KeyEvent.VK_BACK_SPACE)  ||
		           (c == KeyEvent.VK_DELETE))) {
		          
		          e.consume();
		        }}
		});
		txtmoney=new JTextField();
		txtmoney.addKeyListener(new KeyAdapter() {
		    public void keyTyped(KeyEvent e) {
		        char c = e.getKeyChar();
		        if (!((c >= '0') && (c <= '9') ||
		           (c == KeyEvent.VK_BACK_SPACE) || (c=='.') ||
		           (c == KeyEvent.VK_DELETE))) {
		          
		          e.consume();
		        }}
		});
		lblshowbalance=new JLabel("Available Balance");
		txtshowbalance=new JTextField();
		txtshowbalance.setText(String.valueOf(Global.balance));
		txtshowbalance.setEditable(false);
		
		btndash=new JButton("Dashboard");
		btndash.setBounds(140, 100, 100, 40);
		btndash.setBackground(new Color(251,96,68));
		btndash.setBorder(null);
		btndash.setForeground(Color.WHITE);
		btndep=new JButton("Transfer");
		btndep.setBounds(125, 100, 100, 40);
		lbluseraccno.setBounds(100, 0, 350, 20);
		lblmoney.setBounds(100,70, 200, 20);
		txtuseraccno.setBounds(100, 0, 150, 25);
		txtmoney.setBounds(100,65, 150, 25);
		lblshowbalance.setBounds(100,35, 200, 20);
		txtshowbalance.setBounds(100,30, 150, 25);
		lbluseraccno.setFont(font4);
		lblmoney.setFont(font4);
		txtuseraccno.setFont(font4);
		txtmoney.setFont(font4);
		lblshowbalance.setFont(font4);
		txtshowbalance.setFont(font4);
		btndep.setBackground(new Color(251,96,68));
		btndep.setBorder(null);
		btndep.setForeground(Color.WHITE);
		
		showacc=new JTextField();
		showacc.setText(String.valueOf(Global.account_no));
		showacc.setBounds(500, 50, 160, 30);
		showacc.setFont(font2);
		showacc.setBorder(null);
		showacc.setEditable(false);
		
		
		label1=new JLabel("Balance Transfer");
		label2=new JLabel("Bank Machine");
		label1.setForeground(Color.WHITE);
		label2.setForeground(Color.WHITE);
		label1.setBounds(10, 0, 250, 110);
		label2.setBounds(10, 10, 230, 80);
		label1.setFont(font3);
		label2.setFont(font2);
		
		
		p2.add(txtuseraccno);
		p2.add(txtshowbalance);
		
		p2.add(txtmoney);
		p1.add(lbluseraccno);
		p1.add(lblmoney);
		p1.add(lblshowbalance);
		p2.add(btndep);
		p1.add(btndash);
		//defining buttons of panel4
		b1=new JButton("1");
		b2=new JButton("2");
		b3=new JButton("3");
		b4=new JButton("4");
		b5=new JButton("5");
		b6=new JButton("6");
		b7=new JButton("7");
		b8=new JButton("8");
		b9=new JButton("9");
		b10=new JButton(".");
		b11=new JButton("0");
		b12=new JButton("<");
		
		
		b1.setBackground(new Color(48,109,61));
		b1.setForeground(Color.WHITE);
		b1.setBorder(new LineBorder(Color.WHITE, 1));
		
		b2.setBackground(new Color(48,109,61));
		b2.setForeground(Color.WHITE);
		b2.setBorder(new LineBorder(Color.WHITE, 1));
		
		b3.setBackground(new Color(48,109,61));
		b3.setForeground(Color.WHITE);
		b3.setBorder(new LineBorder(Color.WHITE, 1));
		
		b4.setBackground(new Color(48,109,61));
		b4.setForeground(Color.WHITE);
		b4.setBorder(new LineBorder(Color.WHITE, 1));
		
		b5.setBackground(new Color(48,109,61));
		b5.setForeground(Color.WHITE);
		b5.setBorder(new LineBorder(Color.WHITE, 1));
		
		b6.setBackground(new Color(48,109,61));
		b6.setForeground(Color.WHITE);
		b6.setBorder(new LineBorder(Color.WHITE, 1));
		
		b7.setBackground(new Color(48,109,61));
		b7.setForeground(Color.WHITE);
		b7.setBorder(new LineBorder(Color.WHITE, 1));
		
		b8.setBackground(new Color(48,109,61));
		b8.setForeground(Color.WHITE);
		b8.setBorder(new LineBorder(Color.WHITE, 1));
		
		b9.setBackground(new Color(48,109,61));
		b9.setForeground(Color.WHITE);
		b9.setBorder(new LineBorder(Color.WHITE, 1));
		
		b10.setBackground(new Color(48,109,61));
		b10.setForeground(Color.WHITE);
		b10.setBorder(new LineBorder(Color.WHITE, 1));
		
		
		b11.setBackground(new Color(48,109,61));
		b11.setForeground(Color.WHITE);
		b11.setBorder(new LineBorder(Color.WHITE, 1));
		
		b12.setBackground(new Color(48,109,61));
		b12.setForeground(Color.WHITE);
		b12.setBorder(new LineBorder(Color.WHITE, 1));
		
		
		p4.add(b1);
		p4.add(b2);
		p4.add(b3);
		p4.add(b4);
		p4.add(b5);
		p4.add(b6);
		p4.add(b7);
		p4.add(b8);
		p4.add(b9);
		p4.add(b10);
		p4.add(b11);
		p4.add(b12);
		
		panel1.setBackground(new Color(58,57,57));
		panel2.setBackground(Color.WHITE);
		panel3.setBackground(new Color(58,57,57));

		//setting title bar of internal frame to null
				BasicInternalFrameUI ui = (BasicInternalFrameUI)dep.getUI();
				ui.setNorthPane(null);
		
		
		//setting panels and labels
		p1.setBounds(0, 0, 350, 150);
		p1.setBackground(Color.WHITE);
		p2.setBounds(350, 0,350,150 );
		p2.setBackground(Color.WHITE);
		p3.setBounds(0,150, 350, 250);
		p3.setBackground(Color.WHITE);
		p4.setBounds(350, 150, 320, 250);
		p4.setVisible(true);
		
		panel1.add(label1);
		panel1.add(showacc);
		panel3.add(label2);
		panel2.add(p1);
		panel2.add(p2);
		panel2.add(p3);
		panel2.add(p4);
		
		
		
		dep.add(panel1);
		dep.add(panel2);
		dep.add(panel3);
		
		
		dep.setVisible(true);
		dep.setSize(700,650);
		dashboard.add(dep);
		
		innertra it=new innertra();
		b1.addActionListener(it);
		b2.addActionListener(it);
		b3.addActionListener(it);
		b4.addActionListener(it);
		b5.addActionListener(it);
		b6.addActionListener(it);
		b7.addActionListener(it);
		b8.addActionListener(it);
		b9.addActionListener(it);
		b10.addActionListener(it);
		b11.addActionListener(it);
		b12.addActionListener(it);
		
		innertransfer itr=new innertransfer();
		btndep.addActionListener(itr);
		
		innerbuttons ip=new innerbuttons();
		btndash.addActionListener(ip);
		
	}
	
	//designing withdrawal frame
		JLabel lblbalance;
		JTextField txtbalance;
	public void balanceEnquiry(){
		font3=new Font("Courier New", Font.BOLD, 25);
		font1=new Font("Century Gothic",Font.PLAIN,23);;
		font4=new Font("Calibri", Font.PLAIN, 20);
		dep=new JInternalFrame();
		dep.setLayout(null);
		panel1=new JPanel();
		panel1.setLayout(null);
		panel2=new JPanel();
		panel2.setLayout(null);
		panel3=new JPanel();
		panel3.setLayout(null);
		panel1.setBounds(0, 0, 700, 105);
		panel2.setBounds(0, 110, 700, 400);
		panel3.setBounds(0, 515, 700, 105);
		
		lblbalance=new JLabel("Available Balance");
		txtbalance=new JTextField();
		txtbalance.setText(String.valueOf(Global.balance));
		txtbalance.setEditable(false);
		lblbalance.setBounds(120, 50, 200, 40);
		txtbalance.setBounds(370, 50, 160, 40);
		lblbalance.setFont(font4);
		txtbalance.setFont(font1);
		
		label1=new JLabel("Balance Enquiry");
		label2=new JLabel("Bank Machine");
		label1.setForeground(Color.WHITE);
		label2.setForeground(Color.WHITE);
		label1.setBounds(10, 0, 250, 110);
		label2.setBounds(10, 10, 230, 80);
		label1.setFont(font3);
		label2.setFont(font2);
		
		
		btndash=new JButton("Dashboard");
		btndash.setBounds(260, 200, 100, 40);
		btndash.setBackground(new Color(251,96,68));
		btndash.setBorder(null);
		btndash.setForeground(Color.WHITE);
		
		panel1.setBackground(new Color(58,57,57));
		panel2.setBackground(Color.WHITE);
		panel3.setBackground(new Color(58,57,57));
		
		//setting title bar of internal frame to null
		BasicInternalFrameUI ui = (BasicInternalFrameUI)dep.getUI();
		ui.setNorthPane(null);
		
		panel2.add(btndash);
		panel2.add(lblbalance);
		panel2.add(txtbalance);
		panel1.add(label1);
		panel3.add(label2);
		dep.add(panel1);
		dep.add(panel2);
		dep.add(panel3);
		
		
		
		dep.setVisible(true);
		dep.setSize(700,650);
		dashboard.add(dep);
		innerbuttons ip=new innerbuttons();
		btndash.addActionListener(ip);
		
	}
	
	
	private JLabel lblw,lblbal,lblsum;
	private JButton btnwi;
	
	private JTextField txtbal, txtsum;
	private JInternalFrame wit;
	
	
	public void withdraw(){
		wit=new JInternalFrame();
		wit.setLayout(null);
		
	
		lblw=new JLabel("Balance Withdrawl");
		lblbal=new JLabel("Available balance");
		lblsum=new JLabel("Enter Sum to Withdraw");
		txtbal=new JTextField();
		txtbal.setEditable(false);
		txtbal.setText(String.valueOf(Global.balance));
		txtsum=new JTextField();
		txtsum.addKeyListener(new KeyAdapter() {
		    public void keyTyped(KeyEvent e) {
		        char c = e.getKeyChar();
		        if (!((c >= '0') && (c <= '9') ||
		           (c == KeyEvent.VK_BACK_SPACE)|| (c=='.') ||
		           (c == KeyEvent.VK_DELETE))) {
		          
		          e.consume();
		        }}
		});
		btnwi=new JButton("Withdraw");
		
		
		


		label2=new JLabel("Bank Machine");
		label1.setForeground(Color.WHITE);
		label2.setForeground(Color.WHITE);
		label1.setBounds(10, 0, 250, 110);
		label2.setBounds(10, 10, 230, 80);
		label1.setFont(font3);
		label2.setFont(font2);
		
		
		showacc=new JTextField();
		showacc.setText(String.valueOf(Global.account_no));
		showacc.setBounds(500, 50, 160, 30);
		showacc.setFont(font2);
		showacc.setBorder(null);
		showacc.setEditable(false);
		showacctype=new JTextField();
		showacctype.setText(String.valueOf(Global.accounttype));
		showacctype.setBounds(500, 0, 160, 30);
		showacctype.setFont(font1);
		showacctype.setBorder(null);
		showacctype.setEditable(false);
		
		//defining adding labels.text field and buttons in panel2
		
		
		btndash=new JButton("Dashboard");
	
		lblbal.setBounds(100, 0, 200, 30);	
		lblsum.setBounds(100,45, 200, 30);
		btndash.setBounds(140, 100, 100, 40);
		txtbal.setBounds(100, 0, 150, 30);
		txtsum.setBounds(100, 45, 150, 30);
		btnwi.setBounds(125, 100, 100, 40);
		btnwi.setBackground(new Color(251,96,68));
		btnwi.setBorder(null);
		btndash.setBackground(new Color(251,96,68));
		btndash.setBorder(null);
		
		btnwi.setForeground(Color.WHITE);
		btndash.setForeground(Color.WHITE);
		font3=new Font("Courier New", Font.BOLD, 25);
		lblw.setForeground(Color.WHITE);
		lblw.setFont(font3);
		lblw.setBounds(10, 0, 300, 110);
		font4=new Font("Calibri", Font.PLAIN, 20);
		lblbal.setFont(font4);
		lblsum.setFont(font4);
		txtbal.setFont(font4);
		txtsum.setFont(font4);
		panel1=new JPanel();
		panel1.setLayout(null);
		panel2=new JPanel();
		panel2.setLayout(null);
		panel3=new JPanel();
		panel3.setLayout(null);
		panel1.setBounds(0, 0, 700, 105);
	
		//setting title bar of internal frame to null
				BasicInternalFrameUI ui = (BasicInternalFrameUI)wit.getUI();
				ui.setNorthPane(null);
		
		
		
		
		panel2.setBounds(0, 110, 700, 400);
		panel3.setBounds(0, 515, 700, 105);
		panel1.setBackground(new Color(58,57,57));
		panel2.setBackground(Color.WHITE);
		panel3.setBackground(new Color(58,57,57));
		
		
		
		
		p1=new JPanel();
		p2=new JPanel();
		p3=new JPanel();
		p4=new JPanel();
		p1.setLayout(null);
		p2.setLayout(null);
		p3.setLayout(null);
		p4.setLayout(new GridLayout(4,3));
		
		
		//defining buttons of panel4
				b1=new JButton("1");
				b2=new JButton("2");
				b3=new JButton("3");
				b4=new JButton("4");
				b5=new JButton("5");
				b6=new JButton("6");
				b7=new JButton("7");
				b8=new JButton("8");
				b9=new JButton("9");
				b10=new JButton(".");
				b11=new JButton("0");
				b12=new JButton("<");
				
				
				b1.setBackground(new Color(48,109,61));
				b1.setForeground(Color.WHITE);
				b1.setBorder(new LineBorder(Color.WHITE, 1));
				
				b2.setBackground(new Color(48,109,61));
				b2.setForeground(Color.WHITE);
				b2.setBorder(new LineBorder(Color.WHITE, 1));
				
				b3.setBackground(new Color(48,109,61));
				b3.setForeground(Color.WHITE);
				b3.setBorder(new LineBorder(Color.WHITE, 1));
				
				b4.setBackground(new Color(48,109,61));
				b4.setForeground(Color.WHITE);
				b4.setBorder(new LineBorder(Color.WHITE, 1));
				
				b5.setBackground(new Color(48,109,61));
				b5.setForeground(Color.WHITE);
				b5.setBorder(new LineBorder(Color.WHITE, 1));
				
				b6.setBackground(new Color(48,109,61));
				b6.setForeground(Color.WHITE);
				b6.setBorder(new LineBorder(Color.WHITE, 1));
				
				b7.setBackground(new Color(48,109,61));
				b7.setForeground(Color.WHITE);
				b7.setBorder(new LineBorder(Color.WHITE, 1));
				
				b8.setBackground(new Color(48,109,61));
				b8.setForeground(Color.WHITE);
				b8.setBorder(new LineBorder(Color.WHITE, 1));
				
				b9.setBackground(new Color(48,109,61));
				b9.setForeground(Color.WHITE);
				b9.setBorder(new LineBorder(Color.WHITE, 1));
				
				b10.setBackground(new Color(48,109,61));
				b10.setForeground(Color.WHITE);
				b10.setBorder(new LineBorder(Color.WHITE, 1));
				
				
				b11.setBackground(new Color(48,109,61));
				b11.setForeground(Color.WHITE);
				b11.setBorder(new LineBorder(Color.WHITE, 1));
				
				b12.setBackground(new Color(48,109,61));
				b12.setForeground(Color.WHITE);
				b12.setBorder(new LineBorder(Color.WHITE, 1));
				
				
				p4.add(b1);
				p4.add(b2);
				p4.add(b3);
				p4.add(b4);
				p4.add(b5);
				p4.add(b6);
				p4.add(b7);
				p4.add(b8);
				p4.add(b9);
				p4.add(b10);
				p4.add(b11);
				p4.add(b12);
				
				p1.add(lblbal);
				p1.add(lblsum);
				p1.add(btndash);		
		
				p2.add(txtbal);
				p2.add(txtsum);
				p2.add(btnwi);
		p1.setBounds(0, 0, 350, 150);
		p1.setBackground(Color.WHITE);
		p2.setBounds(350, 0,350,150 );
		p2.setBackground(Color.WHITE);
		p3.setBounds(0,150, 350, 250);
		p3.setBackground(Color.WHITE);
		p4.setBounds(350, 150, 320, 250);
		
		panel1.add(showacctype);
		panel1.add(showacc);
		panel1.add(lblw);
		panel2.add(p1);
		panel2.add(p2);
		panel2.add(p3);
		panel2.add(p4);
		panel3.add(label2);
		
		p4.setVisible(true);
		
		wit.add(panel1);
		wit.add(panel2);
		wit.add(panel3);
		
		
		
		
		innerwith iw=new innerwith();
		b1.addActionListener(iw);
		b2.addActionListener(iw);
		b3.addActionListener(iw);
		b4.addActionListener(iw);
		b5.addActionListener(iw);
		b6.addActionListener(iw);
		b7.addActionListener(iw);
		b8.addActionListener(iw);
		b9.addActionListener(iw);
		b10.addActionListener(iw);
		b11.addActionListener(iw);
		b12.addActionListener(iw);
		
		innerwithdraw iwa=new innerwithdraw();
		btnwi.addActionListener(iwa);
		
		
		
		
		innerbuttons ip=new innerbuttons();
		btndash.addActionListener(ip);
		
		
		
		
		
		
		
		
		wit.setVisible(true);
		wit.setSize(700,650);
		dashboard.add(wit);
	}
	

		
	
	
	public static void main(String args[]) {
		// TODO Auto-generated method stub
		new Dashboard();
	}
	
	
	public class innerdashboard implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if(e.getSource()==btnover){
				new Overdraft();
				indashboard.dispose();
			}
			if(e.getSource()==btnswitchaccount){
				int option;
				option =  JOptionPane.showConfirmDialog(null, "Are you sure to Switch Account?", "Switch", JOptionPane.YES_NO_OPTION,1);
	            if(option==0){
	            	dashboard.dispose();
					new Accounts();
	            }
				if(option==1){
					
				}
			}
			if(e.getSource()==btnlogout){
				int option;
				option =  JOptionPane.showConfirmDialog(null, "Are you sure to Logout?", "Logout", JOptionPane.YES_NO_OPTION,1);
	            if(option==0){
	            	dashboard.dispose();
					new Home();
	            }
				if(option==1){
					
				}
			}
			else if(e.getSource()==btnp){
				profile();
				indashboard.dispose();
			}
			else if(e.getSource()==btntr){
				transfer();
				indashboard.dispose();
			}
			else if(e.getSource()==btncash){
				fastcash();
				indashboard.dispose();
			}
			else if(e.getSource()==btnen){
				balanceEnquiry();
				indashboard.dispose();
			}
			else if(e.getSource()==btnw){
				withdraw();
				indashboard.dispose();
			}
			else if(e.getSource()==btnd){
				
				deposit();
				indashboard.dispose();
			}
			else if(e.getSource()==btnt){
				transactions();
				indashboard.dispose();
			}
		}
		
	}
	
	
	public class innerbutton  implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
		
				if(e.getSource()==b1){
				
				txtpin.setText(txtpin.getText().concat("1"));
					
					}
				
			
				if(e.getSource()==b2){
				txtpin.setText(txtpin.getText().concat("2"));
				}
				if(e.getSource()==b3){
				txtpin.setText(txtpin.getText().concat("3"));
				}
				if(e.getSource()==b4){
				txtpin.setText(txtpin.getText().concat("4"));
				}
				if(e.getSource()==b5){
				txtpin.setText(txtpin.getText().concat("5"));
				}
				if(e.getSource()==b6){
				txtpin.setText(txtpin.getText().concat("6"));
				}
				if(e.getSource()==b7){
				txtpin.setText(txtpin.getText().concat("7"));
				}
				if(e.getSource()==b8){
				txtpin.setText(txtpin.getText().concat("8"));
				}
				if(e.getSource()==b9){
				txtpin.setText(txtpin.getText().concat("9"));
				}
				if(e.getSource()==b10){
					txtpin.setText(txtpin.getText().concat("."));
				}
				if(e.getSource()==b11){
				txtpin.setText(txtpin.getText().concat("0"));
				
				}if(e.getSource()==b12){
				int length = txtpin.getText().length();
				int number = txtpin.getText().length() - 1;
				String store;
				if (length > 0) {
					StringBuilder back = new StringBuilder(txtpin.getText());
					back.deleteCharAt(number);
					store = back.toString();
					txtpin.setText(store);
			}
			}
			

			}
		
		
		}



		public class innerwith implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				// TODO Auto-generated method stub
					
			
					if(e.getSource()==b1){
					
					txtsum.setText(txtsum.getText().concat("1"));
						
						}
					
				
					if(e.getSource()==b2){
					txtsum.setText(txtsum.getText().concat("2"));
					}
					if(e.getSource()==b3){
					txtsum.setText(txtsum.getText().concat("3"));
					}
					if(e.getSource()==b4){
					txtsum.setText(txtsum.getText().concat("4"));
					}
					if(e.getSource()==b5){
					txtsum.setText(txtsum.getText().concat("5"));
					}
					if(e.getSource()==b6){
					txtsum.setText(txtsum.getText().concat("6"));
					}
					if(e.getSource()==b7){
					txtsum.setText(txtsum.getText().concat("7"));
					}
					if(e.getSource()==b8){
					txtsum.setText(txtsum.getText().concat("8"));
					}
					if(e.getSource()==b9){
					txtsum.setText(txtsum.getText().concat("9"));
					}
					if(e.getSource()==b10){
						txtsum.setText(txtsum.getText().concat("."));
					}
					if(e.getSource()==b11){
					txtsum.setText(txtsum.getText().concat("0"));
					
					}if(e.getSource()==b12){
					int length = txtsum.getText().length();
					int number = txtsum.getText().length() - 1;
					String store;
					if (length > 0) {
						StringBuilder back = new StringBuilder(txtsum.getText());
						back.deleteCharAt(number);
						store = back.toString();
						txtsum.setText(store);
				}
				}
				

				
			}
			
		}


		


		
		public class innertra implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				// TODO Auto-generated method stub
					
					if(e.getSource()==b1){
					
					txtmoney.setText(txtmoney.getText().concat("1"));
						
						}
					
				
					if(e.getSource()==b2){
					txtmoney.setText(txtmoney.getText().concat("2"));
					}
					if(e.getSource()==b3){
					txtmoney.setText(txtmoney.getText().concat("3"));
					}
					if(e.getSource()==b4){
					txtmoney.setText(txtmoney.getText().concat("4"));
					}
					if(e.getSource()==b5){
					txtmoney.setText(txtmoney.getText().concat("5"));
					}
					if(e.getSource()==b6){
					txtmoney.setText(txtmoney.getText().concat("6"));
					}
					if(e.getSource()==b7){
					txtmoney.setText(txtmoney.getText().concat("7"));
					}
					if(e.getSource()==b8){
					txtmoney.setText(txtmoney.getText().concat("8"));
					}
					if(e.getSource()==b9){
					txtmoney.setText(txtmoney.getText().concat("9"));
					}
					if(e.getSource()==b10){
						txtmoney.setText(txtmoney.getText().concat("."));
					}
					if(e.getSource()==b11){
					txtmoney.setText(txtmoney.getText().concat("0"));
					
					}if(e.getSource()==b12){
					int length = txtmoney.getText().length();
					int number = txtmoney.getText().length() - 1;
					String store;
					if (length > 0) {
						StringBuilder back = new StringBuilder(txtmoney.getText());
						back.deleteCharAt(number);
						store = back.toString();
						txtmoney.setText(store);
				}
				}
				

				
			}
			
			
			
			
		}
		public class innerdeposit implements ActionListener{
			BlDeposit bl=new BlDeposit();
			ElDeposit ed=new ElDeposit();
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(e.getSource()==btndep){
					if(txtpin.getText().isEmpty()){
						JOptionPane.showMessageDialog(null, "Please enter sum to Deposit"+"\n"+"", "Empty TextField", JOptionPane.WARNING_MESSAGE);
						return;
					}
					if(txtpin.getText().equals("")){
						JOptionPane.showMessageDialog(null, "Please enter sum to Deposit"+"\n"+"", "Empty TextField", JOptionPane.WARNING_MESSAGE);
						return;
					}
					if(Double.parseDouble(txtpin.getText())==0){
						JOptionPane.showMessageDialog(null, "Please enter sum to Deposit"+"\n"+"", "Empty TextField", JOptionPane.WARNING_MESSAGE);
						txtpin.setText("");
						return;
					}
					double overdraft=Double.parseDouble(txtoverdraftdeposit.getText());
					if(overdraft>0){
						if(showacctype.getText().equals("Super Account") || showacctype.getText().equals("Saver Account")){
							 int accno;
							 double amount,amount1;
							 accno=Integer.parseInt(showacc.getText());
								amount=Double.parseDouble(txtoverdraftdeposit.getText());
								amount1=Double.parseDouble(txtpin.getText());
								
								double total=amount-amount1;
							ed.setAccountno(accno);
							ed.setBalance1(amount);
							ed.setBalance2(amount1);
							ed.setBalance3(total);
							if(total<0){
								
								JOptionPane.showMessageDialog(null, "Please Pay the current Overdraft to Deposit sum");
								txtpin.setText("");
							}
							if(total>0 || total==0){
							int count=bl.depositOverdraft(ed);
							if(count==1){
								Global.overdraft=ed.getBalance3();
								JOptionPane.showMessageDialog(null, "Overdraft Payed Successfully");
								txtoverdraftdeposit.setText(String.valueOf(total));
								txtpin.setText("");
							}
							if(count==0){
								JOptionPane.showMessageDialog(null, "Failed");
							}
							}
							
						}
		
					}
					if(overdraft==0 || overdraft<0){
					if(showacctype.getText().equals("Super Account")){
						 int accno;
						 double amount,amount1;
						
						accno=Integer.parseInt(showacc.getText());
						amount=Double.parseDouble(txtdep.getText());
						amount1=Double.parseDouble(txtpin.getText());
						
						double total=amount+amount1+(0.01*amount1);
						
						ed.setAccountno(accno);
						ed.setBalance1(amount);
						ed.setBalance2(amount1);
						ed.setBalance3(total);
						if(total>0){
						int count=bl.depositBalance(ed);
						if(count==1){
							Global.balance=ed.getBalance3();
							JOptionPane.showMessageDialog(null, "Deposited succesfully");
							txtdep.setText(String.valueOf(total));
							txtpin.setText("");
							
						}
						if(count==0){
							JOptionPane.showMessageDialog(null, "Deposition Failed");
						}
						}
					}
					else if(showacctype.getText().equals("Basic Account") || showacctype.getText().equals("Saver Account")){
						 int accno;
						 double amount,amount1;
						
						accno=Integer.parseInt(showacc.getText());
						amount=Double.parseDouble(txtdep.getText());
						amount1=Double.parseDouble(txtpin.getText());
						
						double total=amount+amount1;
						
						ed.setAccountno(accno);
						ed.setBalance1(amount);
						ed.setBalance2(amount1);
						ed.setBalance3(total);
						if(total>0){
						int count=bl.depositBalance(ed);
						if(count==1){
							Global.balance=ed.getBalance3();
							JOptionPane.showMessageDialog(null, "Deposited succesfully");
							txtdep.setText(String.valueOf(total));
							txtpin.setText("");
							
						}
						if(count==0){
							JOptionPane.showMessageDialog(null, "Deposition Failed");
						}
						}
					}
					}
					
				}
					
				
					
				}
			
				}
		public class innerwithdraw implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				ElWithdraw ed=new ElWithdraw();
				BlWithdraw bl=new BlWithdraw();

				if(e.getSource()==btnwi){
					if(txtsum.getText().isEmpty()){
						JOptionPane.showMessageDialog(null, "Please enter sum to withdraw"+"\n"+"", "Empty TextField", JOptionPane.WARNING_MESSAGE);
						return;
					}
					if(txtsum.getText().equals("")){
						JOptionPane.showMessageDialog(null, "Please enter sum to withdraw"+"\n"+"", "Empty TextField", JOptionPane.WARNING_MESSAGE);
						return;
					}
					if(Double.parseDouble(txtsum.getText())==0){
						JOptionPane.showMessageDialog(null, "Please enter sum to withdraw"+"\n"+"", "Empty TextField", JOptionPane.WARNING_MESSAGE);
						txtsum.setText("");
						return;
					}
					int accno;
					 double amount,amount1;
					
					accno=Integer.parseInt(showacc.getText());
					amount=Double.parseDouble(txtbal.getText());
					amount1=Double.parseDouble(txtsum.getText());
					
					double total=amount-amount1;
				
					ed.setAccountno(accno);
					ed.setBalance1(amount);
					ed.setBalance2(amount1);
					ed.setBalance3(total);
					
					if(total>0 || total==0){
					int count=bl.withdrawBalance(ed);
					if(count==1){
						
						Global.balance=ed.getBalance3();
						JOptionPane.showMessageDialog(null, "Withdrawn succesfully");
						txtbal.setText(String.valueOf(total));
						txtsum.setText("");
						
						
						
					}
					
					if(count==0){
						JOptionPane.showMessageDialog(null, "Withdrawn Failed");
					}
					}
					else if(total<0){
						JOptionPane.showMessageDialog(null, "You don't have sufficient balance"+"\n"+"Please Try Again Later", "Not Enough Balance", JOptionPane.WARNING_MESSAGE);
						txtsum.setText("");
						return;
					}
					
								
				}
			}
			
		}
		public class innertransfer implements ActionListener{
			ElTransfer et=new ElTransfer();
			
			BlTransfer bt=new BlTransfer();
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(e.getSource()==btndep){
					if(txtuseraccno.getText().isEmpty()){
						JOptionPane.showMessageDialog(null, "Please enter Account Number"+"\n"+"to be Transferred to", "Empty TextField", JOptionPane.WARNING_MESSAGE);
						return;
					}
					if(txtuseraccno.getText().equals("")){
						JOptionPane.showMessageDialog(null, "Please enter sum to Transfer"+"\n"+"to be Transferred to", "Empty TextField", JOptionPane.WARNING_MESSAGE);
						return;
					}
					if(Integer.parseInt(txtuseraccno.getText())==0){
						JOptionPane.showMessageDialog(null, "Please enter sum to Transfer"+"\n"+"to be Transferred to", "Empty TextField", JOptionPane.WARNING_MESSAGE);
						txtuseraccno.setText("");
						return;
					}
					if(txtmoney.getText().isEmpty()){
						JOptionPane.showMessageDialog(null, "Please enter sum to Transfer"+"\n"+"", "Empty TextField", JOptionPane.WARNING_MESSAGE);
						return;
					}
					if(txtmoney.getText().equals("")){
						JOptionPane.showMessageDialog(null, "Please enter sum to Transfer"+"\n"+"", "Empty TextField", JOptionPane.WARNING_MESSAGE);
						return;
					}
					if(Integer.parseInt(txtmoney.getText())==0){
						JOptionPane.showMessageDialog(null, "Please enter sum to Transfer"+"\n"+"", "Empty TextField", JOptionPane.WARNING_MESSAGE);
						txtmoney.setText("");
						return;
					}
					
					
					int accno,desaccno;
					double avamount,amount1,total;
					double transamount;
					accno=Integer.parseInt(showacc.getText());
					desaccno=Integer.parseInt(txtuseraccno.getText());
					avamount=Double.parseDouble(txtshowbalance.getText());
					amount1=Double.parseDouble(txtmoney.getText());
					
					
					
					
					total=avamount-amount1;
					
					et.setAccountno(accno);
					et.setDesaccountno(desaccno);
					et.setBalance1(avamount);
					et.setBalance2(amount1);
					et.setBalance3(total);
					ResultSet res=bt.searchBalance(et);
					try{
						if(res.next()){
							
							Global.transbalance=res.getDouble("balance");
						}
						
					}
					catch(SQLException ep){
						ep.printStackTrace();
					
					}
					double transtotal;
					transamount=Global.transbalance;
					transtotal=transamount+amount1;
					et.setTranstotal(transtotal);
					et.setTranspreviousbalance(transamount);
					
					if(total>0 || total==0){
					int count=bt.transferBalance(et);
					
					if(count==1){
						
						Global.balance=et.getBalance3();
						JOptionPane.showMessageDialog(null, "Sum has been Transferred");
						txtshowbalance.setText(String.valueOf(total));
						txtmoney.setText("");
					}
					}
					if(total<0){
						JOptionPane.showMessageDialog(null, "You don't have sufficient balance"+"\n"+"Please Try Again Later", "Not Enough Balance", JOptionPane.WARNING_MESSAGE);
						txtmoney.setText("");
						return;
					}
					
				}
			}
			
		}
		
		
		public class innerfastcash implements ActionListener{
			ElFastCash efc=new ElFastCash();
			BlFastCash bfc=new BlFastCash();
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				if(e.getSource()==btn50){
					int accno;
					double avamount,clickedamount,total;
					accno=Integer.valueOf(showacc.getText());
					avamount=Double.valueOf(txtshowbalancefastcash.getText());
					clickedamount=50;
					total=avamount-clickedamount;
					
					efc.setAccountno(accno);
					efc.setBalance1(avamount);
					efc.setBalance2(clickedamount);
					efc.setBalance3(total);
					if(total>0 || total==0){
					int count=bfc.fastcashBalance(efc);
					if(count==1){
						Global.balance=efc.getBalance3();
						JOptionPane.showMessageDialog(null, "�50 Withdrawn");
						txtshowbalancefastcash.setText(String.valueOf(total));
					}
					if(count==0){
						JOptionPane.showMessageDialog(null, "Withdrawn Failed");
					}
					}
					
					else if(total<0){
						JOptionPane.showMessageDialog(null, "You don't have sufficient balance"+"\n"+"Please Try Again Later", "Not Enough Balance", JOptionPane.WARNING_MESSAGE);
						
						return;
					}
				}
				if(e.getSource()==btn100){
					int accno;
					double avamount,clickedamount,total;
					accno=Integer.valueOf(showacc.getText());
					avamount=Double.valueOf(txtshowbalancefastcash.getText());
					clickedamount=100;
					total=avamount-clickedamount;
					
					efc.setAccountno(accno);
					efc.setBalance1(avamount);
					efc.setBalance2(clickedamount);
					efc.setBalance3(total);
					if(total>0 || total==0){
					int count=bfc.fastcashBalance(efc);
					if(count==1){
						Global.balance=efc.getBalance3();
						JOptionPane.showMessageDialog(null, "�100 Withdrawn");
						txtshowbalancefastcash.setText(String.valueOf(total));
					}
					if(count==0){
						JOptionPane.showMessageDialog(null, "Withdrawn Failed");
					}
					}
					
					else if(total<0){
						JOptionPane.showMessageDialog(null, "You don't have sufficient balance"+"\n"+"Please Try Again Later", "Not Enough Balance", JOptionPane.WARNING_MESSAGE);
						
						return;
					}
				}
				if(e.getSource()==btn150){
					int accno;
					double avamount,clickedamount,total;
					accno=Integer.valueOf(showacc.getText());
					avamount=Double.valueOf(txtshowbalancefastcash.getText());
					clickedamount=150;
					total=avamount-clickedamount;
					
					efc.setAccountno(accno);
					efc.setBalance1(avamount);
					efc.setBalance2(clickedamount);
					efc.setBalance3(total);
					if(total>0 || total==0){
					int count=bfc.fastcashBalance(efc);
					if(count==1){
						Global.balance=efc.getBalance3();
						JOptionPane.showMessageDialog(null, "�150 Withdrawn");
						txtshowbalancefastcash.setText(String.valueOf(total));
					}
					if(count==0){
						JOptionPane.showMessageDialog(null, "Withdrawn Failed");
					}
					}
					
					else if(total<0){
						JOptionPane.showMessageDialog(null, "You don't have sufficient balance"+"\n"+"Please Try Again Later", "Not Enough Balance", JOptionPane.WARNING_MESSAGE);
						
						return;
					}
				}
				if(e.getSource()==btn200){
					int accno;
					double avamount,clickedamount,total;
					accno=Integer.valueOf(showacc.getText());
					avamount=Double.valueOf(txtshowbalancefastcash.getText());
					clickedamount=200;
					total=avamount-clickedamount;
					
					efc.setAccountno(accno);
					efc.setBalance1(avamount);
					efc.setBalance2(clickedamount);
					efc.setBalance3(total);
					if(total>0 || total==0){
					int count=bfc.fastcashBalance(efc);
					if(count==1){
						Global.balance=efc.getBalance3();
						JOptionPane.showMessageDialog(null, "�200 Withdrawn");
						txtshowbalancefastcash.setText(String.valueOf(total));
					}
					if(count==0){
						JOptionPane.showMessageDialog(null, "Withdrawn Failed");
					}
					}
					
					else if(total<0){
						JOptionPane.showMessageDialog(null, "You don't have sufficient balance"+"\n"+"Please Try Again Later", "Not Enough Balance", JOptionPane.WARNING_MESSAGE);
						
						return;
					}
				}
				if(e.getSource()==btn250){
					int accno;
					double avamount,clickedamount,total;
					accno=Integer.valueOf(showacc.getText());
					avamount=Double.valueOf(txtshowbalancefastcash.getText());
					clickedamount=250;
					total=avamount-clickedamount;
					
					efc.setAccountno(accno);
					efc.setBalance1(avamount);
					efc.setBalance2(clickedamount);
					efc.setBalance3(total);
					if(total>0 || total==0){
					int count=bfc.fastcashBalance(efc);
					if(count==1){
						Global.balance=efc.getBalance3();
						JOptionPane.showMessageDialog(null, "�250 Withdrawn");
						txtshowbalancefastcash.setText(String.valueOf(total));
					}
					if(count==0){
						JOptionPane.showMessageDialog(null, "Withdrawn Failed");
					}
					}
					
					else if(total<0){
						JOptionPane.showMessageDialog(null, "You don't have sufficient balance"+"\n"+"Please Try Again Later", "Not Enough Balance", JOptionPane.WARNING_MESSAGE);
						
						return;
					}
				}
				
			}
			
		}
		public class innertran implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(e.getSource()==btndash){
					new Dashboard();
					dashboard.dispose();
				}
				if(e.getSource()==showtran){
					int accno;
					accno=Integer.parseInt(showacc.getText());
					ElTransaction elt=new ElTransaction();
					elt.setAccno(accno);
					BlTransaction blt=new BlTransaction();
					ResultSet res=blt.showTransaction(elt);
					
					tbltran.setModel(DbUtils.resultSetToTableModel(res));
				}
			}
			
		}
		public class innerbuttons implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(e.getSource()==btndash){
					new Dashboard();
					dashboard.dispose();
				}
				if(e.getSource()==btncloseacc){
					new CloseAccount();
					dashboard.dispose();
				}
				if(e.getSource()==btnchangeacc){
					new AccountType();
					dashboard.dispose();
				}
				if(e.getSource()==btneditprofile){
					new EditProfile();
					dashboard.dispose();
				}
			}
			
		}
}
	
	

