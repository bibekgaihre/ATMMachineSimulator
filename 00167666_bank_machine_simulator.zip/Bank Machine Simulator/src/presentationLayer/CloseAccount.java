package presentationLayer;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.plaf.basic.BasicInternalFrameUI;

import businessLayer.BlCloseAccount;
import entityLayer.ElCloseAccount;
import entityLayer.Global;
import net.proteanit.sql.DbUtils;

public class CloseAccount {
	private JFrame f;
	private JLabel label1,label2;
	private JLabel note;
	private JTable tblaccount;
	private JInternalFrame dep;
	private JScrollPane jp;
	private String[] columnNames = {"Account Number", "Balance","Date/Time"};
	private String data[][]={};
	private JPanel panel1,panel2,panel3;
	private JPanel p1,p2;
	private Font font1,font2,font3,font4;
	private JTextField showacc;
	private JLabel lblbalance,lbluser;
	private JLabel lbloverdraft;
	private JTextField txtoverdraft;
	private JTextField txtbalance,txtuser;
	private JButton showacclist,deleteaccount,btndash;
	public CloseAccount() {
		// TODO Auto-generated constructor stub
		font2=new Font("Courier New", Font.BOLD, 30);
		font4=new Font("Calibri", Font.PLAIN, 17);
		font1=new Font("Century Gothic",Font.BOLD,13);
		f=new JFrame();
		f.setTitle("Close Account");
		f.setSize(700, 650);
		f.setDefaultCloseOperation(3);
		f.setLocationRelativeTo(null);
		f.setVisible(true);
		dep=new JInternalFrame();
		dep.setLayout(null);
		
		
		label1=new JLabel("Close Account");
		label2=new JLabel("Bank Machine");
		
		note=new JLabel("Note: To Delete Your Account Your Current Balance must be Transferred to Another Account");
		note.setBounds(40, 0, 600, 60);
		note.setFont(font1);
		panel1=new JPanel();
		panel1.setLayout(null);
		panel2=new JPanel();
		panel2.setLayout(null);
		panel3=new JPanel();
		panel3.setLayout(null);
		panel1.setBounds(0, 0, 700, 105);
		panel2.setBounds(0, 110, 700, 400);
		panel3.setBounds(0, 515, 700, 105);
		
		
		
		p1=new JPanel();
		p2=new JPanel();
		p1.setLayout(null);
		p2.setLayout(null);
		p1.setBounds(0, 0, 700, 270);
		p1.setBackground(Color.WHITE);
		p2.setBounds(0, 270, 700, 130);
	
		showacc=new JTextField();
		showacc.setText(String.valueOf(Global.account_no));
		showacc.setBounds(500, 50, 160, 30);
		showacc.setFont(font2);
		showacc.setBorder(null);
		showacc.setEditable(false);
		
		showacclist=new JButton("List my accounts");
		showacclist.setBounds(270,225,150,40);
		showacclist.setBackground(new Color(251,96,68));
		showacclist.setBorder(null);
		showacclist.setForeground(Color.WHITE);
		
		btndash=new JButton("Dashboard");
		
		btndash.setBounds(510,225,150,40);
		btndash.setBackground(new Color(251,96,68));
		btndash.setBorder(null);
		btndash.setForeground(Color.WHITE);
		
		
		
		deleteaccount=new JButton("Delete Account");
		deleteaccount.setBounds(50,225,150,40);
		deleteaccount.setBackground(new Color(251,96,68));
		deleteaccount.setBorder(null);
		deleteaccount.setForeground(Color.WHITE);
		
		tblaccount=new JTable(data,columnNames);
		jp=new JScrollPane();
		jp.setViewportView(tblaccount);
		jp.getVerticalScrollBar();
		jp.setBounds(0,0,700,130);
		
		tblaccount.setEnabled(false);
		
		
		lbloverdraft=new JLabel("Current Overdraft");
		lbloverdraft.setFont(font4);
		
		txtoverdraft=new JTextField();
		txtoverdraft.setText(String.valueOf(Global.overdraft));
		txtoverdraft.setFont(font1);
		txtoverdraft.setEditable(false);
		lbloverdraft.setBounds(120, 150, 200, 40);
		txtoverdraft.setBounds(370, 150, 160, 40);
		lblbalance=new JLabel("Available Balance");
		txtbalance=new JTextField();
		txtbalance.setText(String.valueOf(Global.balance));
		lblbalance.setBounds(120, 50, 200, 40);
		txtbalance.setBounds(370, 50, 160, 40);
		lblbalance.setFont(font4);
		txtbalance.setFont(font1);
		txtbalance.setEditable(false);
		lbluser=new JLabel("User ID");
		txtuser=new JTextField();
		txtuser.setText(String.valueOf(Global.user_id));
		lbluser.setBounds(120, 100, 200, 40);
		txtuser.setBounds(370, 100, 160, 40);
		lbluser.setFont(font4);
		txtuser.setFont(font1);
		txtuser.setEditable(false);
		if(Double.parseDouble(txtbalance.getText())==0 ){
			
			showacclist.setEnabled(false);
		}
		else if(Double.parseDouble(txtbalance.getText())!=0){
			deleteaccount.setEnabled(false);
		}
		
		
		label1.setForeground(Color.WHITE);
		label1.setBounds(10, 0, 270, 110);
		label1.setFont(font2);
		label2.setForeground(Color.WHITE);
		label2.setBounds(10, 10, 230, 80);
		label2.setFont(font2);
		
		
		panel1.setBackground(new Color(58,57,57));
		panel2.setBackground(Color.WHITE);
		panel3.setBackground(new Color(58,57,57));
		
		//title bar of internal frame is set null
		BasicInternalFrameUI bi = (BasicInternalFrameUI)dep.getUI();
		bi.setNorthPane(null);
		
		p2.add(jp);
		p1.add(lbluser);
		p1.add(txtuser);
		p1.add(lblbalance);
		p1.add(txtbalance);
		p1.add(lbloverdraft);
		p1.add(txtoverdraft);
		p1.add(deleteaccount);
		p1.add(btndash);
		p1.add(showacclist);
		p1.add(note);
		panel1.add(label1);
		panel1.add(showacc);
		panel2.add(p1);
		panel2.add(p2);
		
		panel3.add(label2);
		
		dep.add(panel1);
		dep.add(panel2);
		dep.add(panel3);
		
		dep.setVisible(true);
		dep.setSize(700,650);
		f.add(dep);
		f.setResizable(false);
		innerdelete id=new innerdelete();
		showacclist.addActionListener(id);
		deleteaccount.addActionListener(id);
		btndash.addActionListener(id);
	}

	
	public static void main(String[] args) {
		new CloseAccount();
	}
	
	public class innerdelete implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if(e.getSource()==showacclist){
				int userid;
				userid=Integer.parseInt(txtuser.getText());
				ElCloseAccount ec=new ElCloseAccount();
				ec.setUserid(userid);
				BlCloseAccount bc=new BlCloseAccount();
				ResultSet res=bc.showAccount(ec);
				tblaccount.setModel(DbUtils.resultSetToTableModel(res));
				
			}
			if(e.getSource()==deleteaccount){
				double showover;
				int accno;
				accno=Integer.parseInt(showacc.getText());
				showover=Double.parseDouble(txtoverdraft.getText());
				ElCloseAccount ec=new ElCloseAccount();
				ec.setAccno(accno);
				BlCloseAccount bc=new BlCloseAccount();
				if(showover==0){
					int count=bc.deleteAccount(ec);
					if(count==1){
						JOptionPane.showMessageDialog(null, "Account Deleted");
						new Accounts();
						f.dispose();
					}
					if(count==0){
						JOptionPane.showMessageDialog(null, "Account Not Deleted", "Deletion failed", JOptionPane.ERROR_MESSAGE);;
					}
				}
				else if(showover>0){
					JOptionPane.showMessageDialog(null, "You must pay your Overdraft to delete account");
				}
				
			}
			if(e.getSource()==btndash){
				new Dashboard();
				
			}
		}
		
	}
	
}
