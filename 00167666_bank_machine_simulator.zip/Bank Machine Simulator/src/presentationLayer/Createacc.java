package presentationLayer;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.plaf.basic.BasicInternalFrameUI;

import businessLayer.BlCreateAccount;
import entityLayer.ElCreateAccount;
import entityLayer.Global;

public class Createacc {
	private JLabel label1,label2;
	private JFrame f;
	private JLabel lblaccno,lblbalance,lblaccounttype;
	private JTextField txtaccno,txtbalance;
	private JTextField txtuser;
	private JLabel lbluser;
	private JComboBox cmbaccounttype;
	private JInternalFrame dep;
	private JButton btnhome,btnsubmit;
	private JPanel panel1,panel2,panel3;
	private Font font1,font2,font3,font4;
	public Createacc() {
		// TODO Auto-generated constructor stub
		font1=new Font("Century Gothic",Font.PLAIN,23);
		font2=new Font("Courier New", Font.BOLD, 30);
		font4=new Font("Calibri", Font.PLAIN, 15);
		font3=new Font("Calibri", Font.PLAIN, 20);
		f=new JFrame();
		f.setTitle("Create Account");
		f.setSize(700, 650);
		f.setDefaultCloseOperation(3);
		f.setLocationRelativeTo(null);
		f.setVisible(true);
		dep=new JInternalFrame();
		dep.setLayout(null);
		label1=new JLabel("Create Account");
		label2=new JLabel("Bank Machine");
		
		panel1=new JPanel();
		panel1.setLayout(null);
		panel2=new JPanel();
		panel2.setLayout(null);
		panel3=new JPanel();
		panel3.setLayout(null);
		panel1.setBounds(0, 0, 700, 105);
		panel2.setBounds(0, 110, 700, 400);
		panel3.setBounds(0, 515, 700, 105);
		
		label1.setForeground(Color.WHITE);
		label1.setBounds(10, 0, 300, 110);
		label1.setFont(font2);
		label2.setForeground(Color.WHITE);
		label2.setBounds(10, 10, 230, 80);
		label2.setFont(font2);
		
		lblaccno=new JLabel("Account No");
		lblaccounttype=new JLabel("Choose Account Type");
		lblbalance=new JLabel("Balance");
		lbluser=new JLabel("Your User ID");
		
		String type[]={"","Basic","Saver","Super"};
		
		
		txtaccno=new JTextField();
		Random ran=new Random();
		int num=ran.nextInt(100000000)+1;
		String value=String.valueOf(num);
		txtaccno.setText(value);
		txtaccno.setEditable(false);
		
		txtbalance=new JTextField();
		txtbalance.setEditable(false);
		txtbalance.setText(String.valueOf(5));
		cmbaccounttype=new JComboBox(type);
		cmbaccounttype.setSelectedItem("");
		btnhome=new JButton("Home");
		btnsubmit=new JButton("Submit");
		txtuser=new JTextField();
		
		cmbaccounttype.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			
			}
		});
		
		lblaccno.setBounds(100, 50, 200, 40);
		lblaccounttype.setBounds(100, 140, 200, 40);
		lblbalance.setBounds(100,185,200,40);
		txtaccno.setBounds(400, 50, 200, 40);
		cmbaccounttype.setBounds(400, 140, 100, 40);
		txtbalance.setBounds(400,185,200,40);
		btnhome.setBounds(150, 290, 100, 50);
		btnsubmit.setBounds(440, 290, 100, 50);
		lbluser.setBounds(100, 95, 200, 40);
		txtuser.setBounds(400, 95, 200, 40);
		txtuser.setEditable(false);
		txtuser.setText(String.valueOf(Global.user_id));
		btnhome.setBackground(new Color(251,96,68));
		btnhome.setBorder(null);
		btnhome.setForeground(Color.WHITE);
		
		btnsubmit.setBackground(new Color(251,96,68));
		btnsubmit.setBorder(null);
		btnsubmit.setForeground(Color.WHITE);
		
		lblaccno.setFont(font3);
		lblaccounttype.setFont(font3);
		lblbalance.setFont(font3);
		lbluser.setFont(font3);
		txtaccno.setFont(font1);
		txtbalance.setFont(font1);
		txtuser.setFont(font1);
		cmbaccounttype.setFont(font1);
		panel1.setBackground(new Color(58,57,57));
		panel2.setBackground(Color.WHITE);
		panel3.setBackground(new Color(58,57,57));
		
		
		//title bar of internal frame is set null
		BasicInternalFrameUI bi = (BasicInternalFrameUI)dep.getUI();
		bi.setNorthPane(null);
		
		
		panel1.add(label1);
		panel2.add(lblaccno);panel2.add(txtuser);
		
		panel2.add(lblbalance);
		panel2.add(lblaccounttype);
		panel2.add(txtaccno);
		panel2.add(txtbalance);
		panel2.add(btnhome);
		panel2.add(btnsubmit);
		panel2.add(cmbaccounttype);
		panel3.add(label2);
		panel2.add(lbluser);
		
		dep.add(panel1);
		dep.add(panel2);
		dep.add(panel3);
		
		dep.setVisible(true);
		dep.setSize(700,650);
		f.add(dep);
		f.setResizable(false);
		
		innercreate ic=new innercreate();
		btnsubmit.addActionListener(ic);
		btnhome.addActionListener(ic);
		cmbaccounttype.addActionListener(ic);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Createacc();
	}
	
	
//	overriding a predefined interface
	public class innercreate implements ActionListener{
		ElCreateAccount ec=new ElCreateAccount();
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==btnhome){
			new Home();
			f.dispose();
		}
		if(e.getSource()==cmbaccounttype){
			String ctype;
			
			ctype=cmbaccounttype.getSelectedItem().toString();
			if(ctype=="Basic"){
				ec.setCtypeid(1);
				txtbalance.setText(String.valueOf(5));
			}
			else if(ctype=="Saver"){
				ec.setCtypeid(2);
				txtbalance.setText(String.valueOf(0));
			}
			else if(ctype=="Super"){
				ec.setCtypeid(3);
				txtbalance.setText(String.valueOf(0));
			}
		}
		if(e.getSource()==btnsubmit){
			if(cmbaccounttype.getSelectedItem().toString()==""){
				JOptionPane.showMessageDialog(null, "Please select an account type");
				return;
			}
			int accno;
			Double balance;
			int user;
			accno=Integer.parseInt(txtaccno.getText());
			balance=Double.parseDouble(txtbalance.getText());
			user=Integer.parseInt(txtuser.getText());
			
			
			
			ec.setAccno(accno);
			ec.setBalance(balance);
			ec.setUserid1(user);
			
			BlCreateAccount bc=new BlCreateAccount();
			int count=bc.insertaccount(ec);
			if(count==1){
				Global.account_no=ec.getAccno();
				JOptionPane.showMessageDialog(null, "Welcome");
				new Accounts();
				f.dispose();
				
			}
			if(count==0){
				JOptionPane.showMessageDialog(null, "Error");
			}
		}
	}
		
	}
}
