


package presentationLayer;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.plaf.basic.BasicInternalFrameUI;

import businessLayer.BlAccounts;
import entityLayer.ElAccounts;
import entityLayer.ElCreateAccount;
import entityLayer.ElHome;
import entityLayer.Global;

public class Accounts {
	private JLabel label1,label2;
	private JFrame f;
	private JInternalFrame dep;
	private JPanel panel1,panel2,panel3;
	private Font font1,font2,font3,font4;
	private JButton b1,b2,b3,b4,b5;
	private JTextField txtuser;
	private JButton btnlogout;
	
	public Accounts() {
		
// TODO Auto-generated constructor stub
		font1=new Font("Century Gothic",Font.PLAIN,23);
		font2=new Font("Courier New", Font.BOLD, 30);
		font4=new Font("Calibri", Font.BOLD, 26);
		font3=new Font("Segoe UI Semibold",Font.PLAIN,20);
		f=new JFrame();
		f.setTitle("Accounts");
		f.setSize(700, 650);
		f.setDefaultCloseOperation(3);
		f.setLocationRelativeTo(null);
		f.setVisible(true);
		dep=new JInternalFrame();
		dep.setLayout(null);
		label1=new JLabel("Accounts");
		label2=new JLabel("Bank Machine");
		
		panel1=new JPanel();
		panel1.setLayout(null);
		panel2=new JPanel();
		panel2.setLayout(null);
		panel3=new JPanel();
		panel3.setLayout(null);
		panel1.setBounds(0, 0, 700, 105);
		panel2.setBounds(0, 110, 700, 400);
		panel3.setBounds(0, 515, 700, 105);
		
		
		btnlogout=new JButton("Log Out");
		btnlogout.setBounds(290, 20, 100, 50);
		btnlogout.setBackground(new Color(247, 32, 32));
		btnlogout.setForeground(Color.WHITE);
		btnlogout.setBorder(null);
		btnlogout.setFont(font3);
		
		
	
		b1=new JButton("Basic Account");
		b2=new JButton("Saver Account");
		b3=new JButton("Super Account");
		b4=new JButton("Home");
		b5=new JButton("Create Account");
		
		b1.setBackground(new Color(100, 149, 237));
		b1.setForeground(Color.WHITE);
		b1.setBorder(null);
		b1.setFont(font4);
		b2.setBackground(new Color(100, 149, 237));
		b2.setForeground(Color.WHITE);
		b2.setBorder(null);
		b2.setFont(font4);
		b3.setBackground(new Color(100, 149, 237));
		b3.setForeground(Color.WHITE);
		b3.setBorder(null);
		b3.setFont(font4);
		b4.setBackground(new Color(251,96,68));
		b4.setForeground(Color.WHITE);
		b4.setBorder(null);
		b5.setBackground(new Color(251,96,68));
		b5.setForeground(Color.WHITE);
		b5.setBorder(null);
		
		
		b1.setBounds(225, 0, 250, 50);
		b2.setBounds(225, 100, 250, 50);
		b3.setBounds(225, 200, 250, 50);
		b4.setBounds(150, 300, 150, 40);
		b5.setBounds(390, 300, 150, 40);
		label1.setForeground(Color.WHITE);
		label1.setBounds(10, 0, 300, 110);
		label1.setFont(font2);
		label2.setForeground(Color.WHITE);
		label2.setBounds(10, 10, 230, 80);
		label2.setFont(font2);
		txtuser=new JTextField();
		txtuser.setBounds(500, 20, 150, 30);
		txtuser.setEditable(false);
		txtuser.setBorder(null);
		txtuser.setText(String.valueOf(Global.user_id));
		txtuser.setFont(font1);
		panel1.setBackground(new Color(58,57,57));
		panel2.setBackground(Color.WHITE);
		panel3.setBackground(new Color(58,57,57));
		
		//title bar of internal frame is set null
				BasicInternalFrameUI bi = (BasicInternalFrameUI)dep.getUI();
				bi.setNorthPane(null);
	
		panel1.add(label1);
		panel1.add(txtuser);
		panel2.add(b1);
		panel2.add(b2);
		panel2.add(b3);
		panel2.add(b4);
		panel2.add(b5);
		panel3.add(btnlogout);
		
		panel3.add(label2);
		dep.add(panel1);
		dep.add(panel2);
		dep.add(panel3);
		dep.setVisible(true);
		dep.setSize(700,650);
		f.add(dep);
		f.setResizable(false);
		inneraccounts ia=new inneraccounts();
		b1.addActionListener(ia);
		b2.addActionListener(ia);
		b3.addActionListener(ia);
		b4.addActionListener(ia);
		b5.addActionListener(ia);
		btnlogout.addActionListener(ia);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Accounts();
	}

	
	
	public class inneraccounts implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if(e.getSource()==btnlogout){
				int option;

	           option =  JOptionPane.showConfirmDialog(null, "Are you sure to Logout?", "Logout", JOptionPane.YES_NO_OPTION,1);
	            if(option==0){
	            	f.dispose();
					new Home();
	            }
				if(option==1){
					
				}
			}
			if(e.getSource()==b1){
				int userid;
				userid=Integer.parseInt(txtuser.getText());
				
				ElAccounts ea=new ElAccounts();
				ea.setUserid(userid);
				
				BlAccounts ba=new BlAccounts();
				ResultSet res=ba.checkAccount(ea);
				try{
					if(res.next()){
						Global.account_no=res.getInt("accno");
						Global.balance=res.getDouble("balance");
						if(res.getInt("acctypeID")==1){
							Global.accounttype="Basic Account";
						}
						Global.accounttypeID=res.getInt("acctypeID");
						JOptionPane.showMessageDialog(null, "Welcome to basic Account");
						new Dashboard();
						f.dispose();
					}
					
					
					
					else{
						JOptionPane.showMessageDialog(null, "you dont have basic account");
					}
					
				}
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			else if(e.getSource()==b2){
				int userid;
				userid=Integer.parseInt(txtuser.getText());
				
				ElAccounts ea=new ElAccounts();
				ea.setUserid(userid);
				
				BlAccounts ba=new BlAccounts();
				ResultSet res=ba.checkAccount1(ea);
				try{
					if(res.next()){
						Global.account_no=res.getInt("accno");
						Global.balance=res.getDouble("balance");
						Global.overdraft=res.getDouble("overdraft");
						if(res.getInt("acctypeID")==2){
							Global.accounttype="Saver Account";
						}
						Global.accounttypeID=res.getInt("acctypeID");
						JOptionPane.showMessageDialog(null, "Welcome to Saver Account");
						f.dispose();
						new Dashboard();
						
						
					}
					
					
					
					else{
						JOptionPane.showMessageDialog(null, "You don't have Saver account");
					}
					
				}
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
			else if(e.getSource()==b3){
				int userid;
				userid=Integer.parseInt(txtuser.getText());
				
				ElAccounts ea=new ElAccounts();
				ea.setUserid(userid);
				
				BlAccounts ba=new BlAccounts();
				ResultSet res=ba.checkAccount2(ea);
				try{
					if(res.next()){
						Global.account_no=res.getInt("accno");
						Global.balance=res.getDouble("balance");
						Global.overdraft=res.getDouble("overdraft");
						if(res.getInt("acctypeID")==3){
							Global.accounttype="Super Account";
						}
						Global.accounttypeID=res.getInt("acctypeID");
						JOptionPane.showMessageDialog(null, "Welcome to Super Account");
						f.dispose();
						new Dashboard();
						
					}
					
					
					
					else{
						JOptionPane.showMessageDialog(null, "You don't have Super account");
					}
					
				}
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
			if(e.getSource()==b4){
				new Home();
				f.dispose();
			}
			if(e.getSource()==b5){
				new Createacc();
				f.dispose();
			}
		}
		
	}
}
