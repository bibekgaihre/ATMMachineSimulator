package presentationLayer;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.plaf.basic.BasicInternalFrameUI;

import businessLayer.BlOverdraft;
import entityLayer.ElOverdraft;
import entityLayer.Global;

public class Overdraft {
	private JLabel label1,label2;
	private JFrame f;
	private JInternalFrame dep;
	private JPanel panel1,panel2,panel3;
	private JButton btnsaver;
	private JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12;
	private JLabel lblloan;
	private JTextField showacc;
	private JTextField txtloan;
	private JButton btnloan,btndash;
	private JPanel p4;
	private JLabel lblacctype;
	private JLabel lblcurrentoverdraft,lblshowbalance;
	private JTextField txtcurrentoverdraft;
	private JTextField txtacctype,txtshowbalance;
	private Font font1,font2,font3,font4;
	public Overdraft() {
		
		font1=new Font("Century Gothic",Font.PLAIN,23);
		font2=new Font("Courier New", Font.BOLD, 30);
		font4=new Font("Calibri", Font.PLAIN, 19);
		font3=new Font("Calibri", Font.PLAIN, 20);
		
		
		
		
		f=new JFrame();
		f.setTitle("Accounts");
		f.setSize(700, 650);
		f.setDefaultCloseOperation(3);
		f.setLocationRelativeTo(null);
		f.setVisible(true);
		dep=new JInternalFrame();
		dep.setLayout(null);
		label1=new JLabel("Overdraft");
		label2=new JLabel("Bank Machine");
		
		
		lblshowbalance=new JLabel("Current Balance");
		txtshowbalance=new JTextField();
		txtshowbalance.setText(String.valueOf(Global.balance));
		lblshowbalance.setBounds(0,290,200,40);
		txtshowbalance.setBounds(170, 290, 170, 40);
		txtshowbalance.setFont(font1);
		txtshowbalance.setEditable(false);
		lblshowbalance.setFont(font4);
		lblcurrentoverdraft=new JLabel("Current Overdraft");
		txtcurrentoverdraft=new JTextField();
		lblcurrentoverdraft.setBounds(0,220,200,40);
		lblcurrentoverdraft.setFont(font4);
		txtcurrentoverdraft.setBounds(170, 220, 170, 40);
		txtcurrentoverdraft.setEditable(false);
		txtcurrentoverdraft.setText(String.valueOf(Global.overdraft));
		txtcurrentoverdraft.setFont(font1);
		lblloan=new JLabel("Enter Overdraft Sum");
		txtloan=new JTextField();
		txtloan.addKeyListener(new KeyAdapter() {
		    public void keyTyped(KeyEvent e) {
		        char c = e.getKeyChar();
		        if (!((c >= '0') && (c <= '9') ||
		           (c == KeyEvent.VK_BACK_SPACE) ||
		           (c == KeyEvent.VK_DELETE))) {
		          
		          e.consume();
		        }}
		});
		btnloan=new JButton("Loan");
		btndash=new JButton("Dashboard");
		lblloan.setFont(font4);
		lblloan.setBounds(0, 150, 200, 40);
		txtloan.setFont(font1);
		txtloan.setBounds(170, 150, 170, 40);
		btnloan.setBounds(200,350 , 100, 40);
		btndash.setBounds(38,350,100,40);
		
		lblacctype=new JLabel("Account Type");
		txtacctype=new JTextField();
		txtacctype.setText(Global.accounttype);
		txtacctype.setEditable(false);
		lblacctype.setBounds(0, 80, 200, 40);
		lblacctype.setFont(font4);
		txtacctype.setBounds(170, 80, 170, 40);
		txtacctype.setFont(font1);
		
		btnsaver=new JButton("� 250");
		btnsaver.setBounds(275, 0, 150, 60);
		btnsaver.setBackground(new Color(37, 67, 121));
		btnsaver.setBorder(new LineBorder(Color.WHITE, 5));
		btnsaver.setForeground(Color.WHITE);
		btnsaver.setFont(font2);
		
		showacc=new JTextField();
		showacc.setText(String.valueOf(Global.account_no));
		showacc.setBounds(500, 50, 160, 30);
		showacc.setFont(font2);
		showacc.setBorder(null);
		showacc.setEditable(false);
		
		
		btnloan.setBackground(new Color(251,96,68));
		btnloan.setBorder(null);
		btnloan.setForeground(Color.WHITE);
		
		btndash.setBackground(new Color(251,96,68));
		btndash.setBorder(null);
		btndash.setForeground(Color.WHITE);
		
		
		
		panel1=new JPanel();
		panel1.setLayout(null);
		panel2=new JPanel();
		panel2.setLayout(null);
		panel3=new JPanel();
		panel3.setLayout(null);
		panel1.setBounds(0, 0, 700, 105);
		panel2.setBounds(0, 110, 700, 400);
		panel3.setBounds(0, 515, 700, 105);
		
		p4=new JPanel();
		p4.setLayout(new GridLayout(4,3));
		
		
		b1=new JButton("1");
		b2=new JButton("2");
		b3=new JButton("3");
		b4=new JButton("4");
		b5=new JButton("5");
		b6=new JButton("6");
		b7=new JButton("7");
		b8=new JButton("8");
		b9=new JButton("9");
		b10=new JButton(".");
		b11=new JButton("0");
		b12=new JButton("<");
		
		b1.setBackground(new Color(48,109,61));
		b1.setForeground(Color.WHITE);
		b1.setBorder(new LineBorder(Color.WHITE, 1));
		
		b2.setBackground(new Color(48,109,61));
		b2.setForeground(Color.WHITE);
		b2.setBorder(new LineBorder(Color.WHITE, 1));
		
		b3.setBackground(new Color(48,109,61));
		b3.setForeground(Color.WHITE);
		b3.setBorder(new LineBorder(Color.WHITE, 1));
		
		b4.setBackground(new Color(48,109,61));
		b4.setForeground(Color.WHITE);
		b4.setBorder(new LineBorder(Color.WHITE, 1));
		
		b5.setBackground(new Color(48,109,61));
		b5.setForeground(Color.WHITE);
		b5.setBorder(new LineBorder(Color.WHITE, 1));
		
		b6.setBackground(new Color(48,109,61));
		b6.setForeground(Color.WHITE);
		b6.setBorder(new LineBorder(Color.WHITE, 1));
		
		b7.setBackground(new Color(48,109,61));
		b7.setForeground(Color.WHITE);
		b7.setBorder(new LineBorder(Color.WHITE, 1));
		
		b8.setBackground(new Color(48,109,61));
		b8.setForeground(Color.WHITE);
		b8.setBorder(new LineBorder(Color.WHITE, 1));
		
		b9.setBackground(new Color(48,109,61));
		b9.setForeground(Color.WHITE);
		b9.setBorder(new LineBorder(Color.WHITE, 1));
		
		b10.setBackground(new Color(48,109,61));
		b10.setForeground(Color.WHITE);
		b10.setBorder(new LineBorder(Color.WHITE, 1));
		
		
		b11.setBackground(new Color(48,109,61));
		b11.setForeground(Color.WHITE);
		b11.setBorder(new LineBorder(Color.WHITE, 1));
		
		b12.setBackground(new Color(48,109,61));
		b12.setForeground(Color.WHITE);
		b12.setBorder(new LineBorder(Color.WHITE, 1));
		
		
		p4.add(b1);
		p4.add(b2);
		p4.add(b3);
		p4.add(b4);
		p4.add(b5);
		p4.add(b6);
		p4.add(b7);
		p4.add(b8);
		p4.add(b9);
		p4.add(b10);
		p4.add(b11);
		p4.add(b12);
		
		p4.setBounds(350, 150, 320, 250);
		p4.setVisible(true);
		
		label1.setForeground(Color.WHITE);
		label1.setBounds(10, 0, 300, 110);
		label1.setFont(font2);
		label2.setForeground(Color.WHITE);
		label2.setBounds(10, 10, 230, 80);
		label2.setFont(font2);
		
		
		
		
		panel1.setBackground(new Color(58,57,57));
		panel2.setBackground(Color.WHITE);
		panel3.setBackground(new Color(58,57,57));
		
		//title bar of internal frame is set null
				BasicInternalFrameUI bi = (BasicInternalFrameUI)dep.getUI();
				bi.setNorthPane(null);
		
				if(Global.accounttypeID==1){
					btnloan.setEnabled(false);
					p4.setEnabled(false);
					txtloan.setEnabled(false);
					btnsaver.setEnabled(false);
				}
				else if(Global.accounttypeID==2){
					btnloan.setEnabled(false);
					p4.setEnabled(false);
					txtloan.setEnabled(false);
				}
				else if(Global.accounttypeID==3){
					btnsaver.setEnabled(false);
				}	
				
				
		panel1.add(showacc);
		panel1.add(label1);
		panel2.add(lblacctype);
		panel2.add(txtacctype);
		panel2.add(btnsaver);
		panel2.add(lblcurrentoverdraft);
		panel2.add(txtcurrentoverdraft);
		panel2.add(p4);
		panel2.add(lblshowbalance);
		panel2.add(txtshowbalance);
		panel2.add(lblloan);
		panel2.add(txtloan);
		panel2.add(btndash);
		panel2.add(btnloan);
		panel3.add(label2);
		dep.add(panel1);
		dep.add(panel2);
		dep.add(panel3);
		dep.setVisible(true);
		dep.setSize(700,650);
		f.add(dep);
		f.setResizable(false);
		
		
		inneroverdraft io=new inneroverdraft();
		
		btndash.addActionListener(io);
		btnloan.addActionListener(io);
		btnsaver.addActionListener(io);
		
		innerkey ik=new innerkey();
		
		b1.addActionListener(ik);
		b2.addActionListener(ik);
		b3.addActionListener(ik);
		b4.addActionListener(ik);
		b5.addActionListener(ik);
		b6.addActionListener(ik);
		b7.addActionListener(ik);
		b8.addActionListener(ik);
		b9.addActionListener(ik);
		b10.addActionListener(ik);
		b11.addActionListener(ik);
		b12.addActionListener(ik);
		
		
	}
	
	
	public static void main(String[] args) {
		new Overdraft();
	}
	
	public class inneroverdraft implements ActionListener{
		ElOverdraft eo=new ElOverdraft();
		BlOverdraft bo=new BlOverdraft();
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if(e.getSource()==btndash){
				new Dashboard();
				f.dispose();
			}
			if(e.getSource()==btnloan){
				if(txtloan.getText().isEmpty()){
					JOptionPane.showMessageDialog(null, "Please enter sum to Overdraft"+"\n"+"", "Empty TextField", JOptionPane.WARNING_MESSAGE);
					return;
				}
				if(txtloan.getText().equals("")){
					JOptionPane.showMessageDialog(null, "Please enter sum to Overdraft"+"\n"+"", "Empty TextField", JOptionPane.WARNING_MESSAGE);
					return;
				}
				if(Double.parseDouble(txtloan.getText())==0){
					JOptionPane.showMessageDialog(null, "Please enter sum to Overdraft"+"\n"+"", "Empty TextField", JOptionPane.WARNING_MESSAGE);
					txtloan.setText("");
					return;
				}
				int accno;
				double overdraft,total,showoverdraft;
				double showb;
				accno=Integer.parseInt(showacc.getText());
				overdraft=Double.parseDouble(txtloan.getText());
				showoverdraft=Double.parseDouble(txtcurrentoverdraft.getText());
				showb=Double.parseDouble(txtshowbalance.getText());
				
				total=overdraft+showoverdraft;
				eo.setAccountno(accno);
				eo.setLoan(total);
				
				if(showb==0 && showoverdraft==0){
					int count=bo.insertOverdraft(eo);
					if(count==1){
						Global.overdraft=eo.getLoan();
						JOptionPane.showMessageDialog(null, "Loan Successfully Taken");
						txtcurrentoverdraft.setText(String.valueOf(total));
						txtloan.setText("");
					}
					else if(count==0){
						JOptionPane.showMessageDialog(null, "Error while taking loan"+"\n"+"Please Try Again Later");
					}
				}
				if(showb==0 && showoverdraft>0){
					JOptionPane.showMessageDialog(null, "Sorry you cannot take loan until you pay your last loan");
					txtloan.setText("");
				}
				if(showb>0){
					JOptionPane.showMessageDialog(null, "To Take Overdraft your balance needs to be 0");
					txtloan.setText("");
				}
				
			}
			if(e.getSource()==btnsaver){
				
				int accno;
				double total;
				double overdraft;
				double showb;
				overdraft=Double.parseDouble(txtcurrentoverdraft.getText());
				accno=Integer.parseInt(showacc.getText());
				total=250+overdraft;
				showb=Double.parseDouble(txtshowbalance.getText());
				eo.setAccountno(accno);
				eo.setLoan(total);
				
					if(total==250 && showb==0){
						
						int count=bo.insertOverdraft(eo);
						if(count==1){
							Global.overdraft=eo.getLoan();
							JOptionPane.showMessageDialog(null, "Loan Successfully Taken");
							txtcurrentoverdraft.setText(String.valueOf(total));
						}
						else if(count==0){
							JOptionPane.showMessageDialog(null, "Error while taking loan"+"\n"+"Please Try Again Later");
						}
						}
						else if(total>250){
							JOptionPane.showMessageDialog(null, "Sorry you cannot take loan until you pay your last loan");
						}
				
				if(showb>0){
					JOptionPane.showMessageDialog(null, "To Take Overdraft your balance needs to be 0");
				}
				
			}
		}
		
	}
	public class innerkey implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if(e.getSource()==b1){
				
				txtloan.setText(txtloan.getText().concat("1"));
					
					}
				
			
				if(e.getSource()==b2){
				txtloan.setText(txtloan.getText().concat("2"));
				}
				if(e.getSource()==b3){
				txtloan.setText(txtloan.getText().concat("3"));
				}
				if(e.getSource()==b4){
				txtloan.setText(txtloan.getText().concat("4"));
				}
				if(e.getSource()==b5){
				txtloan.setText(txtloan.getText().concat("5"));
				}
				if(e.getSource()==b6){
				txtloan.setText(txtloan.getText().concat("6"));
				}
				if(e.getSource()==b7){
				txtloan.setText(txtloan.getText().concat("7"));
				}
				if(e.getSource()==b8){
				txtloan.setText(txtloan.getText().concat("8"));
				}
				if(e.getSource()==b9){
				txtloan.setText(txtloan.getText().concat("9"));
				}
				if(e.getSource()==b10){
					txtloan.setText(txtloan.getText().concat("."));
				}
				if(e.getSource()==b11){
				txtloan.setText(txtloan.getText().concat("0"));
				
				}if(e.getSource()==b12){
				int length = txtloan.getText().length();
				int number = txtloan.getText().length() - 1;
				String store;
				if (length > 0) {
					StringBuilder back = new StringBuilder(txtloan.getText());
					back.deleteCharAt(number);
					store = back.toString();
					txtloan.setText(store);
			}
		}
		
		}
	}
}


