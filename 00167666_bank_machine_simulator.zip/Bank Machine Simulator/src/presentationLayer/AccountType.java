package presentationLayer;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.plaf.basic.BasicInternalFrameUI;

import businessLayer.BlAccountType;
import entityLayer.ElAccountType;
import entityLayer.Global;

public class AccountType {
	private JFrame f;
	private JInternalFrame dep;
	private JPanel panel1,panel2,panel3;
	private JLabel label1,label2;
	private JLabel lblacc,lblcurrentacctype;
	private JRadioButton btnbasic,btnsaver,btnsuper;
	private ButtonGroup btnchangetype;
	private JTextField txtcurrentacctype;
	private Font font1,font2,font3,font4;
	private JButton btndash,btnchange;
	private JTextField showacc;
	public AccountType() {
		// TODO Auto-generated constructor stub
		font2=new Font("Courier New", Font.BOLD, 30);
		font3=new Font("Courier New", Font.BOLD, 25);
		font4=new Font("Calibri", Font.PLAIN, 20);
		font1=new Font("Century Gothic",Font.PLAIN,23);
		f=new JFrame();
		f.setTitle("Change Account");
		f.setSize(700, 650);
		f.setDefaultCloseOperation(3);
		f.setLocationRelativeTo(null);
		f.setVisible(true);
		dep=new JInternalFrame();
		dep.setLayout(null);
		btndash=new JButton("Dashboard");
		btnchange=new JButton("Change");
		label1=new JLabel("Change Account");
		label2=new JLabel("Bank Machine");
		
		
		
		showacc=new JTextField();
		showacc.setText(String.valueOf(Global.account_no));
		showacc.setBounds(500, 50, 160, 30);
		showacc.setFont(font2);
		showacc.setBorder(null);
		showacc.setEditable(false);
		
		
		lblacc=new JLabel("Change Account to:");
		
		
		
		lblcurrentacctype=new JLabel("Current Account Type:");
		txtcurrentacctype=new JTextField();
		txtcurrentacctype.setEditable(false);
		txtcurrentacctype.setText(Global.accounttype);
		btndash=new JButton("Dashboard");
		btnchange=new JButton("Change");
		lblacc.setBounds(150, 50, 200, 40);
		
		lblcurrentacctype.setBounds(150, 100, 200, 40);
		txtcurrentacctype.setBounds(400, 100, 150, 40);
		
		btnbasic=new JRadioButton("Basic");
		btnbasic.setFont(new Font("Century Gothic",Font.CENTER_BASELINE,16));
		btnbasic.setBounds(350, 50, 80, 40);
		btnbasic.setBackground(Color.WHITE);
		
		btnsaver=new JRadioButton("Saver");
		btnsaver.setFont(new Font("Century Gothic",Font.CENTER_BASELINE,16));
		btnsaver.setBounds(440, 50, 80, 40);
		btnsaver.setBackground(Color.WHITE);
		btnsuper=new JRadioButton("Super");
		btnsuper.setFont(new Font("Century Gothic",Font.CENTER_BASELINE,16));
		btnsuper.setBounds(530, 50, 80, 40);
		btnsuper.setBackground(Color.WHITE);
		
		
		btnchangetype=new ButtonGroup();
		btnchangetype.add(btnbasic);
		btnchangetype.add(btnsaver);
		btnchangetype.add(btnsuper);
		if (Global.accounttype=="Basic Account"){
			
			btnbasic.setEnabled(false);
		}
		else if (Global.accounttype=="Saver Account"){
			
			btnsaver.setEnabled(false);
		}
		else if (Global.accounttype=="Super Account"){
			
			btnsuper.setEnabled(false);
		}
		
		
		btndash.setBounds(180, 150, 100, 40);
		btnchange.setBounds(425, 150, 100, 40);
		btndash.setBorder(null);
		btnchange.setBorder(null);
		
		
		btndash.setBackground(new Color(251,96,68));
		btndash.setForeground(Color.WHITE);
		btnchange.setForeground(Color.WHITE);
		btnchange.setBackground(new Color(251,96,68));
		
		lblacc.setFont(font4);
		lblcurrentacctype.setFont(font4);
		panel1=new JPanel();
		panel1.setLayout(null);
		panel2=new JPanel();
		panel2.setLayout(null);
		panel3=new JPanel();
		panel3.setLayout(null);
		panel1.setBounds(0, 0, 700, 105);
		panel2.setBounds(0, 110, 700, 400);
		panel3.setBounds(0, 515, 700, 105);
		label1.setForeground(Color.WHITE);
		label1.setBounds(10, 0, 220, 110);
		label1.setFont(font3);
		label2.setForeground(Color.WHITE);
		label2.setBounds(10, 10, 230, 80);
		label2.setFont(font2);
		
		
		
		
		panel1.setBackground(new Color(58,57,57));
		panel2.setBackground(Color.WHITE);
		panel3.setBackground(new Color(58,57,57));
		
		
		//title bar of internal frame is set null
		BasicInternalFrameUI bi = (BasicInternalFrameUI)dep.getUI();
		bi.setNorthPane(null);
		
		panel1.add(showacc);
		panel2.add(btndash);
		panel2.add(btnchange);
		panel2.add(lblcurrentacctype);
		panel2.add(txtcurrentacctype);
		panel2.add(lblacc);
		panel2.add(btnbasic);
		panel2.add(btnsaver);
		panel2.add(btnsuper);
		panel1.add(label1);
		panel3.add(label2);
		
		
		dep.add(panel1);
		dep.add(panel2);
		dep.add(panel3);
		
		dep.setVisible(true);
		dep.setSize(700,650);
		f.add(dep);
		f.setResizable(false);
		inneraccount ia=new inneraccount();
		btnchange.addActionListener(ia);
		btndash.addActionListener(ia);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new AccountType();
		
	}

	
	public class inneraccount implements ActionListener{
		ElAccountType at=new ElAccountType();
		BlAccountType bt=new BlAccountType();
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
			if(e.getSource()==btnchange){
				int accno;
				
				accno=Integer.parseInt(showacc.getText());
				if(btnbasic.isSelected()){
				
				at.setAccountno(accno);
				int count=bt.changeaccount(at);
				if(count==1){
					JOptionPane.showMessageDialog(null, "Your Account has been Updated.You have been Logged out of system");
					new Home();
				}
				if(count==0){
					JOptionPane.showMessageDialog(null, "Update Failed");
				}
				}
				if(btnsaver.isSelected()){
					
					at.setAccountno(accno);
					int count=bt.changeaccount1(at);
					if(count==1){
						JOptionPane.showMessageDialog(null, "Your Account has been Updated.You have been Logged out of system");
						new Home();
					}
					if(count==0){
						JOptionPane.showMessageDialog(null, "Update Failed");
					}
					}
				if(btnsuper.isSelected()){
					
					at.setAccountno(accno);
					int count=bt.changeaccount2(at);
					if(count==1){
						JOptionPane.showMessageDialog(null, "Your Account has been Updated.You have been Logged out of system");
						new Home();
					}
					if(count==0){
						JOptionPane.showMessageDialog(null, "Update Failed");
					}
					}
			}
			else if(e.getSource()==btndash){
				new Dashboard();
				f.dispose();
			}
			
		}
		
	}
}


