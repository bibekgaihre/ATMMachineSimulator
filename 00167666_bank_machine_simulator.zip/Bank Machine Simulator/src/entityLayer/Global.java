package entityLayer;

public class Global {
	public static String user; 
	public static int account_no;
	public static int user_id;
	public static String pin;
	public static double balance;
	public static double transbalance;
	public static String username;
	public static String address;
	public static String email;
	public static String accounttype;
	public static int accounttypeID;
	public static double overdraft;
	

}
