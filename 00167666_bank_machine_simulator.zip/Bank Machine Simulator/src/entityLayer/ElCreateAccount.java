package entityLayer;

public class ElCreateAccount {
	private int accno;
	private double balance;
	private String ctype;
	private int ctypeid;
	public int getCtypeid() {
		return ctypeid;
	}
	public void setCtypeid(int ctypeid) {
		this.ctypeid = ctypeid;
	}
	public int userid1;
	public String getCtype() {
		return ctype;
	}
	public void setCtype(String ctype) {
		this.ctype = ctype;
	}
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

	public void setUserid1(int userid1) {
		this.userid1 = userid1;
	}
	public int getUserid1() {
		// TODO Auto-generated method stub
		return userid1;
	}


}
