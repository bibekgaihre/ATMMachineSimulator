package entityLayer;

public class ElAccountType {
	
	private int accountno;
	public int getAccountno() {
		return accountno;
	}
	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}
	public int getAccounttypeid() {
		return accounttypeid;
	}
	public void setAccounttypeid(int accounttypeid) {
		this.accounttypeid = accounttypeid;
	}
	private int accounttypeid;
	
}
