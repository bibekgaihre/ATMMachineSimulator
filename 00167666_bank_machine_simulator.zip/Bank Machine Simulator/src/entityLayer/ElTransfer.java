package entityLayer;

public class ElTransfer {
	private int accountno;
	private double balance1;
	private double balance2;
	private double balance3;
	private int desaccountno;
	private double transpreviousbalance,transtotal;


	public double getTranspreviousbalance() {
		return transpreviousbalance;
	}

	public void setTranspreviousbalance(double transpreviousbalance) {
		this.transpreviousbalance = transpreviousbalance;
	}

	public double getTranstotal() {
		return transtotal;
	}

	public void setTranstotal(double transtotal) {
		this.transtotal = transtotal;
	}

	public int getDesaccountno() {
		return desaccountno;
	}

	public void setDesaccountno(int desaccountno) {
		this.desaccountno = desaccountno;
	}

	public double getBalance3() {
		return balance3;
	}

	public void setBalance3(double balance3) {
		this.balance3 = balance3;
	}

	public int getAccountno() {
		return accountno;
	}

	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}

	public double getBalance1() {
		return balance1;
	}

	public void setBalance1(double balance1) {
		this.balance1 = balance1;
	}

	public double getBalance2() {
		return balance2;
	}

	public void setBalance2(double balance2) {
		this.balance2 = balance2;
	}

	

	

}
