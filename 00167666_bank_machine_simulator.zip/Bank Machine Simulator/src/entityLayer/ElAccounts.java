package entityLayer;

public class ElAccounts {
	private int userid;
	
	

	

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}
	
}
