package entityLayer;

public class ElWithdraw {
	private int accountno;
	private double balance1;
	private double balance2;
	private double balance3;
	public double getBalance3() {
		return balance3;
	}

	public void setBalance3(double balance3) {
		this.balance3 = balance3;
	}

	public int getAccountno() {
		return accountno;
	}

	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}

	public double getBalance1() {
		return balance1;
	}

	public void setBalance1(double balance1) {
		this.balance1 = balance1;
	}

	public double getBalance2() {
		return balance2;
	}

	public void setBalance2(double balance2) {
		this.balance2 = balance2;
	}

	
	public ElWithdraw() {
		// TODO Auto-generated constructor stub
	}

}
