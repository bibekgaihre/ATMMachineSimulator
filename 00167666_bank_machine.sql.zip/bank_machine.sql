--
-- Database: `bank_machine`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_account`
--

CREATE TABLE `tbl_account` (
  `accno` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `acctypeID` int(11) NOT NULL,
  `balance` double NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `overdraft` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_account`
--

INSERT INTO `tbl_account` (`accno`, `userid`, `acctypeID`, `balance`, `date`, `overdraft`) VALUES
(86595346, 2361, 1, 0, '2017-04-23 06:23:42', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_accounttype`
--

CREATE TABLE `tbl_accounttype` (
  `acctypeID` int(11) NOT NULL,
  `acctype` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_accounttype`
--

INSERT INTO `tbl_accounttype` (`acctypeID`, `acctype`) VALUES
(1, 'Basic'),
(2, 'Saver'),
(3, 'Super');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transaction`
--

CREATE TABLE `tbl_transaction` (
  `transactionID` int(11) NOT NULL,
  `transactiontype` varchar(50) NOT NULL,
  `accno` int(11) NOT NULL,
  `transferaccno` int(11) DEFAULT NULL,
  `transaction_amount` double NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_transaction`
--

INSERT INTO `tbl_transaction` (`transactionID`, `transactiontype`, `accno`, `transferaccno`, `transaction_amount`, `date`) VALUES
(1, 'Deposit', 86595346, NULL, 88, '2017-04-23 06:23:20'),
(2, 'Withdraw', 86595346, NULL, 55, '2017-04-23 06:23:24'),
(3, 'Withdraw', 86595346, NULL, 38, '2017-04-23 06:23:42');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `userid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contactno` int(36) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pin` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`userid`, `name`, `address`, `contactno`, `email`, `pin`) VALUES
(2361, 'paras poudel', 'dsaas', 544653, 'sadas', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_account`
--
ALTER TABLE `tbl_account`
  ADD PRIMARY KEY (`accno`);

--
-- Indexes for table `tbl_accounttype`
--
ALTER TABLE `tbl_accounttype`
  ADD PRIMARY KEY (`acctypeID`);

--
-- Indexes for table `tbl_transaction`
--
ALTER TABLE `tbl_transaction`
  ADD PRIMARY KEY (`transactionID`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`userid`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_account`
--
ALTER TABLE `tbl_account`
  MODIFY `accno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86595347;
--
-- AUTO_INCREMENT for table `tbl_accounttype`
--
ALTER TABLE `tbl_accounttype`
  MODIFY `acctypeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_transaction`
--
ALTER TABLE `tbl_transaction`
  MODIFY `transactionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2362;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
